package cs.zju;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import cs.zju.utils.DataSetInfo;
import cs.zju.utils.Preprocess;
import weka.classifiers.Classifier;
import weka.classifiers.CostMatrix;
import weka.classifiers.Evaluation;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.meta.MetaCost;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class CrossProjectPrediction {
	private static Instances eclipse_data = null;
	private static Instances libreoffice_data = null;
	private static Instances openstack_data = null;
	public static void read_data() throws Exception{
		String root_path = "C://code_review_paper/cross_project/ours/";
		String eclipse_path = root_path + "eclipse.arff";
		String libreoffice_path = root_path + "libreoffice.arff";
		String openstack_path = root_path + "openstack.arff";
		
		eclipse_data = new DataSource(eclipse_path).getDataSet();
		libreoffice_data = new DataSource(libreoffice_path).getDataSet();
		openstack_data = new DataSource(openstack_path).getDataSet();
		
		eclipse_data.setClassIndex(0);
		libreoffice_data.setClassIndex(0);
		openstack_data.setClassIndex(0);
	}
	
	public static void run() throws Exception{
//		System.out.println("eclipse -> libreoffice");
//		System.out.println("eclipse -> openstack");
//		predict(eclipse_data, libreoffice_data, openstack_data);
//		
//		System.out.println("libreoffice -> eclipse");
//		System.out.println("libreoffice -> openstack");
//		predict(libreoffice_data, eclipse_data, openstack_data);
//		
		System.out.println("openstack -> eclipse");
		System.out.println("openstack -> libreoffice");
		predict(openstack_data, eclipse_data, libreoffice_data);
	}
	
	public static double compute_cost_effective(Classifier cla, Instances TestSet, double ratio) throws Exception{
		HashMap<Integer, Double> map = new HashMap<Integer, Double>();
		double test_positive = DataSetInfo.get_pos_number(TestSet);
		int instance_num_toCheck = (int)(TestSet.numInstances() * ratio);
		if (test_positive > instance_num_toCheck)
			test_positive = instance_num_toCheck;
		
		int num_test = TestSet.numInstances();
		for (int i = 0; i < num_test; i++){
			map.put(i, cla.distributionForInstance(TestSet.instance(i))[1]);
		}
		List<Entry<Integer, Double>> list = new ArrayList<Entry<Integer, Double>>(map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<Integer, Double>>() {

			@Override
			public int compare(Entry<Integer, Double> o1, Entry<Integer, Double> o2) {
				if (o2.getValue() > o1.getValue()){
					return 1;
				}
				else if (o2.getValue() < o1.getValue()){
					return -1;
				}
				return 0;
			}
			
		});
		
		double correct = 0;
		for (int i = 0; i < instance_num_toCheck; i++){
			if (TestSet.instance(list.get(i).getKey()).classValue() == 1){
				correct += 1.0;
			}
		}
		
		return correct / test_positive;
	}
	
	public static void predict(Instances TrainSet, Instances TestSet1, Instances TestSet2) throws Exception{
		int train_positive = Preprocess.get_postive_sample_number(TrainSet);
		int train_negative = TrainSet.numInstances() - train_positive;
		CostMatrix cm = new CostMatrix(2);
		cm.setElement(0, 1, 1);
		cm.setElement(1, 0, ((double) train_negative) / ((double) train_positive));
		MetaCost metacost = new MetaCost();
		Classifier cla = new RandomForest();
		metacost.setClassifier(cla);
		metacost.setCostMatrix(cm);
		metacost.buildClassifier(TrainSet);
		Evaluation eva = new Evaluation(TrainSet);
		eva.evaluateModel(metacost, TestSet1);
		System.out.println("F1-abandoned: " + eva.fMeasure(0));
		System.out.println("F1-merged: " + eva.fMeasure(1));
		System.out.println("accuracy: " + (1 - eva.errorRate()));
		System.out.println("AUC: " + eva.areaUnderROC(0));
//		System.out.println("cost effective: " + compute_cost_effective(metacost, TestSet1, 0.2));
		System.out.println();
		eva.evaluateModel(metacost, TestSet2);
		System.out.println("F1-abandoned: " + eva.fMeasure(0));
		System.out.println("F1-merged: " + eva.fMeasure(1));
		System.out.println("accuracy: " + (1 - eva.errorRate()));
		System.out.println("AUC: " + eva.areaUnderROC(0));
		System.out.println("cost effective: " + compute_cost_effective(metacost, TestSet2, 0.2));
		
		System.out.println();
	}
	
}
