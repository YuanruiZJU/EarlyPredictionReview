package cs.zju;

import cs.zju.predictionmodels.CostSensitivePredictionModel;
import cs.zju.predictionmodels.NaivePredictionModel;
import cs.zju.predictionmodels.RandomGuess;
import cs.zju.predictionmodels.ResamplePredictionModel;
import cs.zju.predictionmodels.SmotePredictionModel;
import cs.zju.utils.Preprocess;

public class Main {
	private static String path = "C://code_review_paper/arff_file_baseline/eclipse/";
	private static String trainFileName;
	private static String testFileName;
	
	private static void run_baselines() throws Exception{
		trainFileName = "train_total.arff";
		testFileName = "test_total.arff";
		String root_path = "C://bug_report_rq/revision_discussion1/baseline/";
		path = root_path + "eclipse/";
		naive_classifiers(false, "random_forest");
		naive_classifiers(false, "SMO");
//		use_cost_sensitive("random_forest");
		
//		path = root_path + "netbeans/";
//		naive_classifiers(false, "SMO");
//		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
//		
		
//		use_cost_sensitive("random_forest");
//		
//		path = root_path + "firefox/";
//		naive_classifiers(false, "SMO");
//		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
//		path = root_path + "thunderbird/";
//		naive_classifiers(false, "SMO");
//		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
//		path = root_path + "mozilla/";
//		naive_classifiers(false, "random_forest");
//		naive_classifiers(false, "SMO");
	}
	
	public static void run_my_paper() throws Exception{
		trainFileName = "train_final.arff";
		testFileName = "test_final.arff";
		String root_path = "C://bug_report_rq/revision_discussion1/final_arff/";
		path = root_path + "eclipse/";
		naive_classifiers(false, "random_forest");
		
//		path = root_path + "netbeans/";
//		naive_classifiers(false, "random_forest");
//		
//		path = root_path + "mozilla/";
//		naive_classifiers(false, "random_forest");
//		
//		path = root_path + "firefox/";
//		naive_classifiers(false, "random_forest");
//		
//		path = root_path + "thunderbird/";
//		naive_classifiers(false, "random_forest");
	}
	
	public static void run_dimension(String dimensionName) throws Exception{
		String root_path = "C://dimensions/";
		
		trainFileName = "train_" + dimensionName + ".arff";
		testFileName = "test_" + dimensionName + ".arff";
		path = root_path + dimensionName + "/eclipse/";
		naive_classifiers(false, "random_forest");
		
		path = root_path + dimensionName + "/netbeans/";
		naive_classifiers(false, "random_forest");
		
		path = root_path + dimensionName + "/mozilla/";
		naive_classifiers(false, "random_forest");
		
		path = root_path + dimensionName + "/firefox/";
		naive_classifiers(false, "random_forest");
		
		path = root_path + dimensionName + "/thunderbird/";
		naive_classifiers(false, "random_forest");
	}
	
	public static void run_dims() throws Exception{
		String dimension = "exp";
		run_dimension(dimension);
		
		dimension = "readability";
		run_dimension(dimension);
		
		dimension = "social";
		run_dimension(dimension);
		
		dimension = "structural";
		run_dimension(dimension);
		
		dimension = "text";
		run_dimension(dimension);
	}
	public static void run_my_paper_variant() throws Exception{
		trainFileName = "train_final.arff";
		testFileName = "test_final.arff";
		path = "C://arff3/eclipse/";
		naive_classifiers(false, "SMO");
		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
		path = "C://arff3/netbeans/";
		naive_classifiers(false, "SMO");
		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
		path = "C://arff3/mozilla/";
		naive_classifiers(false, "SMO");
		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
		path = "C://arff3/firefox/";
		naive_classifiers(false, "SMO");
		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
		
		path = "C://arff3/thunderbird/";
		naive_classifiers(false, "SMO");
		naive_classifiers(false, "random_forest");
//		use_cost_sensitive("random_forest");
	}
	
	public static void run_random() throws Exception{
		path = "C://code_review_paper/arff_file_my_paper/eclipse/";
		random();
		
		path = "C://code_review_paper/arff_file_my_paper/libreoffice/";
		random();
		
		path = "C://code_review_paper/arff_file_my_paper/openstack/";
		random();
	}
	
	public static void run_different_classifier(String classifier_name) throws Exception{
		testFileName = "test_final.arff";
		trainFileName = "train_final.arff";
		
		String rootPath = "C://bug_report_rq/rq1/";
		path = rootPath + "eclipse/";
		naive_classifiers(false, classifier_name);
		
		
		path = rootPath + "netbeans/";
		naive_classifiers(false, classifier_name);
		
		path = rootPath + "mozilla/";
		naive_classifiers(false, classifier_name);
		
		path = rootPath + "firefox/";
		naive_classifiers(false, classifier_name);
		
		path = rootPath + "thunderbird/";
		naive_classifiers(false, classifier_name);
	}
	
	public static void main(String[] args)throws Exception{
//		naive_classifiers(false, "bayes_net");
//		baseline();
		
//		run_my_paper_variant();
//		run_my_paper();
		run_baselines();
		
//		run_dims();
//		run_different_classifier("decision_tree");
//		run_different_classifier("naive_bayes");
//		run_different_classifier("logistic");
//		run_different_classifier("SMO");
		
//		use_smote("bayes_net");
//		run_random();
//		CrossProjectPrediction.read_data();
//		CrossProjectPrediction.run();
//		run_different_classifier();
//		naive_classifiers(false, "random_forest");
//		normalize("eclipse");
//		normalize("netbeans");
//		normalize("mozilla");
//		normalize("firefox");
//		normalize("thunderbird");
		
//		split("eclipse", 0);
//		split("eclipse", 1);
//		
//		split("netbeans", 0);
//		split("netbeans", 1);
//		
//		split("firefox", 0);
//		split("firefox", 1);
//		
//		split("mozilla", 0);
//		split("mozilla", 1);
//		
//		split("thunderbird", 0);
//		split("thunderbird", 1);
	}
	
	public static void normalize(String project) throws Exception{
		String filePath = "C://rq3/" + project + ".arff";
		String storePath = "C://rq3/" + project + "_normalize.arff";
		Preprocess.normalizeOneSet(filePath, storePath);
	}
	
	public static void split(String project, int classValue) throws Exception{
		String filePath = "C://rq3/" + project + ".arff";
		String storePath = "C://rq3/" + project + classValue + ".arff";
		Preprocess.SplitAttr(filePath, storePath, classValue);
	}
	
	public static void random() throws Exception{
		RandomGuess rg = new RandomGuess();
		int folds_num = 10;
		double recall = 0.5;
		String my_dir = path;
		rg.set_project_set(my_dir, folds_num, recall);
		rg.Evaluate();
	}
	
	public static void use_smote(String classifier_name) throws Exception{
		SmotePredictionModel smp = new SmotePredictionModel(classifier_name);
		smp.setFileName(trainFileName, testFileName);
		smp.set_dir(path);
		smp.Evaluate();
	}
	
	public static void use_cost_sensitive(String classifier_name) throws Exception{
		CostSensitivePredictionModel cspm = new CostSensitivePredictionModel(classifier_name);
		cspm.setFileName(trainFileName, testFileName);
		cspm.set_dir(path);
		cspm.Evaluate();
	}
	
	public static void naive_classifiers(boolean resample, String classifier_name) throws Exception{
		if (!resample) {
			NaivePredictionModel npm = new NaivePredictionModel(classifier_name);
			npm.setFileName(trainFileName, testFileName);
			System.out.println(path);
			npm.set_dir(path);
			npm.Evaluate();
		} else {
			ResamplePredictionModel rpm = new ResamplePredictionModel(classifier_name);
			rpm.setFileName(trainFileName, testFileName);
			rpm.set_dir(path);
			rpm.Evaluate();
		}
	}
}
