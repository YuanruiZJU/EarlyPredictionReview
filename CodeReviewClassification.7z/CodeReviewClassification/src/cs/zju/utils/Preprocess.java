package cs.zju.utils;

import weka.core.Instances;
import weka.core.Attribute;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import weka.core.converters.ConverterUtils.DataSource;

public class Preprocess {
	public static void normailize(Instances DataSet1, Instances DataSet2) throws Exception{
		for (int i = 0; i < DataSet1.numAttributes(); i++){
			Attribute attr = DataSet1.attribute(i);
			if (attr.isNumeric()){
				double min_value = DataSet1.instance(0).value(attr);
				double max_value = DataSet1.instance(0).value(attr);
				
				for (int j = 0; j < DataSet1.numInstances(); j++){
					if (min_value > DataSet1.instance(j).value(attr))
						min_value = DataSet1.instance(j).value(attr);
					if (max_value < DataSet1.instance(j).value(attr))
						max_value = DataSet1.instance(j).value(attr);
				}
				
				for (int j = 0; j < DataSet2.numInstances(); j++){
					if (min_value > DataSet2.instance(j).value(attr))
						min_value = DataSet2.instance(j).value(attr);
					if (max_value < DataSet2.instance(j).value(attr))
						max_value = DataSet2.instance(j).value(attr);
				}
				
				for (int j = 0; j < DataSet1.numInstances(); j++){
					double value = DataSet1.instance(j).value(attr);
					value = (value - min_value) / (max_value - min_value);
					DataSet1.instance(j).setValue(attr, value);
				}
				
				for (int j = 0; j < DataSet2.numInstances(); j++){
					double value = DataSet2.instance(j).value(attr);
					value = (value - min_value) / (max_value - min_value);
					DataSet2.instance(j).setValue(attr, value);
				}
			}
		}
	}
	
	public static void normalizeOneSet(String filePath, String storePath) throws Exception{
		Instances DataSet = new DataSource(filePath).getDataSet();
		for (int i = 0; i < DataSet.numAttributes(); i++){
			Attribute attr = DataSet.attribute(i);
			if (attr.isNumeric()){
				double min_value = DataSet.instance(0).value(attr);
				double max_value = DataSet.instance(0).value(attr);
				
				for (int j = 0; j < DataSet.numInstances(); j++){
					if (min_value > DataSet.instance(j).value(attr))
						min_value = DataSet.instance(j).value(attr);
					if (max_value < DataSet.instance(j).value(attr))
						max_value = DataSet.instance(j).value(attr);
				}
				
				for (int j = 0; j < DataSet.numInstances(); j++){
					double value = DataSet.instance(j).value(attr);
					value = (value - min_value) / (max_value - min_value);
					DataSet.instance(j).setValue(attr, value);
				}
			}
		}
		BufferedWriter out = new BufferedWriter(new FileWriter(storePath));
		out.write(DataSet.toString());
		out.close();
	}
	
	public static void SplitAttr(String filePath, String storePath, int classValue) throws Exception {
		Instances dataset = new DataSource(filePath).getDataSet();
		dataset.setClassIndex(0);
		int instNum = dataset.numInstances(); 
		for (int j = instNum-1; j >= 0; j--){
			if (dataset.instance(j).classValue() != classValue){
				dataset.delete(j);
			}
		}
		System.out.println(dataset.numInstances());
		BufferedWriter out = new BufferedWriter(new FileWriter(storePath));
		out.write(dataset.toString());
		out.close();
	}
	
	public static int get_attr_index(Instances dataset, String attr_name){
		int num_attr = dataset.numAttributes();
		for (int i = 0; i < num_attr; i++){
			Attribute attr = dataset.attribute(i);
			if (attr.name().equals(attr_name))
				return i;
		}
		return -1;
	}
	
	public static Instances sample(Instances dataset, double ratio){
		Instances newset = new Instances(dataset);
		newset.setClassIndex(0);
		Instances retset = new Instances(dataset, 0);
		int num_instance = newset.numInstances();
		double num_remain = num_instance * ratio;
		Random random = new Random();
		int valid = 0;
		int invalid = 0;
		System.out.println(num_remain);
		for (int i = 0; i < num_remain;){
			int s = random.nextInt(num_instance) % num_instance;
			if (newset.instance(s).classValue() == 0){
				if (valid < num_remain / 2){
					retset.add(newset.instance(s));
					newset.delete(s);
					num_instance = newset.numInstances();
					valid += 1;
					i ++;
					continue;
				}
			}
			if (newset.instance(s).classValue() == 1){
				if (invalid < num_remain / 2){
					retset.add(newset.instance(s));
					newset.delete(s);
					num_instance = newset.numInstances();
					invalid += 1;
					i ++;
					continue;
				}
			}
			
		}
		System.out.println("invalid: " + invalid + "valid: "+ valid);
		return retset;
	}
	
	public static int get_postive_sample_number(Instances dataset){
		int data_num = dataset.numInstances();
		int ret = 0;
		for (int i = 0; i < data_num; i++){
			if (dataset.instance(i).classValue() == 1)
				ret ++;
		}
		return ret;
	}
}
