package cs.zju.utils;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ArrayList;
import java.util.Comparator;

import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.core.Instance;
import weka.core.Instances;

public class EvaluationState {
	private Evaluation eva;
	private double cost_effective;
	
	public void setClaAndData(Classifier cla, Instances TrainSet, 
			Instances TestSet) throws Exception{
		TrainSet.deleteAttributeAt(1);
		cla.buildClassifier(TrainSet);
		cost_effective = compute_cost_effective(cla, TestSet, 0.2);
		eva = new Evaluation(TrainSet);
		TestSet.deleteAttributeAt(1);
		eva.evaluateModel(cla, TestSet);
	}
	
	public void compute_all_cost_effective(Classifier cla, Instances TestSet, String file_path) throws Exception{
		String[] headers = {"x", "y"};
		ResultToCSV result = new ResultToCSV(headers, file_path);
		for (int k = 1; k <= 100; k ++){
			double f = (double) k / 100.0;
			double ce = compute_cost_effective(cla, TestSet, f);
			String[] contents = {""+f,
					""+ce};
			result.write_contents(contents);
		}
		result.close();
	}
	
	public double compute_cost_effective(Classifier cla, Instances TestSet, double ratio) throws Exception{
		HashMap<Integer, Double> map = new HashMap<Integer, Double>();
		double test_positive = DataSetInfo.get_pos_number(TestSet);
		int instance_num_toCheck = (int)(TestSet.numInstances() * ratio);
		test_positive = (double) instance_num_toCheck;
		
		
		int num_test = TestSet.numInstances();
		Instances temp_TestSet = new Instances(TestSet);
		temp_TestSet.deleteAttributeAt(1);
		for (int i = 0; i < num_test; i++){
			Instance temp_inst = temp_TestSet.instance(i);
			map.put(i, cla.distributionForInstance(temp_inst)[1]);
//			if (temp_inst.classValue() != cla.classifyInstance(temp_inst)){
//				System.out.println(TestSet.instance(i).value(1));
//			}
		}
		List<Entry<Integer, Double>> list = new ArrayList<Entry<Integer, Double>>(map.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<Integer, Double>>() {

			@Override
			public int compare(Entry<Integer, Double> o1, Entry<Integer, Double> o2) {
				if (o2.getValue() > o1.getValue()){
					return 1;
				}
				else if (o2.getValue() < o1.getValue()){
					return -1;
				}
				return 0;
			}
			
		});
		
		double correct = 0;
		for (int i = 0; i < instance_num_toCheck; i++){
			if (TestSet.instance(list.get(i).getKey()).classValue() == 1){
				correct += 1.0;
			}
//			else{
//				System.out.println(TestSet.instance(list.get(i).getKey()).value(1));
//			}
		}
		
		return correct / test_positive;
	}
	
	public void showInfoAndStore(){
		System.out.println("AUC: " + this.getAuc(0));
		System.out.println("precision0 " + this.getPrecision(0));
		System.out.println("precision1 " + this.getPrecision(1));
		System.out.println("recall0: " + this.getRecall(0));
		System.out.println("recall1: " + this.getRecall(1));
		System.out.println("fMeassure0: " + this.getFmeassure(0));
		System.out.println("fMeassure1: " + this.getFmeassure(1));
		System.out.println("cost_effective: " + this.getCostEffective());
		System.out.println("balanced_accuracy: " + this.getBalancedAccuracy());
	}
	
	public void store(ResultToCSV rtcsv) throws IOException{
		String[] contents = {
				""+this.getAuc(0),
				""+this.getPrecision(0),
				""+this.getPrecision(1),
				""+this.getRecall(0),
				""+this.getRecall(1),
				""+this.getFmeassure(0),
				""+this.getFmeassure(1),
				""+this.getAccuracy(),
				""+this.getCostEffective(),
				""+this.getBalancedAccuracy()
		};
		rtcsv.write_contents(contents);
	}
	
	public double getAuc(int class_index){
		return eva.areaUnderROC(class_index);
	}
	
	public double getPrecision(int class_index){
		return eva.precision(class_index);
	}
	
	public double getRecall(int class_index){
		return eva.recall(class_index);
	}
	
	public double getFmeassure(int class_index){
		return eva.fMeasure(class_index);
	}
	
	public double getAccuracy(){
		return 1 - eva.errorRate();
	}
	
	public double getCostEffective(){
		return this.cost_effective;
	}
	
	public double getBalancedAccuracy(){
		return this.getRecall(0) * 0.5 + this.getRecall(1) * 0.5;
	}
}
