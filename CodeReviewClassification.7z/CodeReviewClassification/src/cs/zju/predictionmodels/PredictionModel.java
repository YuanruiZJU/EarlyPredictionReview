package cs.zju.predictionmodels;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import cs.zju.utils.DataSetInfo;
import cs.zju.utils.EvaluationState;
import cs.zju.utils.Preprocess;
import cs.zju.utils.ResultToCSV;
import weka.classifiers.Classifier;
import weka.classifiers.bayes.BayesNet;
import weka.classifiers.bayes.NaiveBayes;
import weka.classifiers.functions.Logistic;
import weka.classifiers.functions.SMO;
import weka.classifiers.trees.J48;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;

public class PredictionModel {
	protected String my_dir;
	protected EvaluationState evas;
	protected ResultToCSV rtcsv;
	protected double average_fmeassure0;
	protected double average_fmeassure1;
	protected double average_precision0;
	protected double average_precision1;
	protected double average_recall0;
	protected double average_recall1;
	protected double average_accuracy;
	protected double average_auc;
	protected double average_cost_effective;
	protected double average_balanced_accuracy;
	protected String classifier_name=null;
	protected String trainFileName;
	protected String testFileName;
	
	public void set_dir(String dir){
		my_dir = dir;
	}
	
	public void setFileName(String train, String test){
		trainFileName = train;
		testFileName = test;
	}
	
	protected Classifier get_classifier(String classifier_name){
		Classifier cla = null;
		if (classifier_name.equals("bayes_net")){
			cla = new BayesNet();
		} else if (classifier_name.equals("random_forest")){
			cla = new RandomForest();
		} else if (classifier_name.equals("naive_bayes")){
			cla = new NaiveBayes();
		} else if (classifier_name.equals("decision_tree")){
			cla = new J48();
		} else if (classifier_name.equals("logistic")){
			cla = new Logistic();
		} else if (classifier_name.equals("SMO")){
			cla = new SMO();
		}
		return cla;
	}
	
	protected void initialize_numbers(){
		average_fmeassure0 = 0.0;
		average_fmeassure1 = 0.0;
		average_precision0 = 0.0;
		average_precision1 = 0.0;
		average_recall0 = 0.0;
		average_recall1 = 0.0;
		average_accuracy = 0.0;
		average_auc = 0.0;
		average_cost_effective=0.0;
		average_balanced_accuracy = 0.0;
	}
	
	protected void getAvg(){
		average_fmeassure0 /= 10;
		average_fmeassure1 /= 10;
		average_precision0 /= 10;
		average_precision1 /= 10;
		average_recall0 /= 10;
		average_recall1 /= 10;
		average_accuracy /= 10;
		average_auc /= 10;
		average_cost_effective /= 10;
		average_balanced_accuracy /= 10;
	}
	
	protected void update_average_numbers(){
		average_fmeassure0 += evas.getFmeassure(0);
		average_fmeassure1 += evas.getFmeassure(1);
		average_precision0 += evas.getPrecision(0);
		average_precision1 += evas.getPrecision(1);
		average_recall0 += evas.getRecall(0);
		average_recall1 += evas.getRecall(1);
		average_auc += evas.getAuc(0);
		average_accuracy += evas.getAccuracy();
		average_cost_effective += evas.getCostEffective();
		average_balanced_accuracy += evas.getBalancedAccuracy();
	}
	
	protected void new_rtcsv(String filename) throws IOException{
		String[] headers = {"AUC", "precision0", "precision1", 
				"recall0", "recall1", "fmeasure0", "fmeasure1", 
				"accuracy", "cost_effective", "balanced_accuracy"};
		rtcsv = new ResultToCSV(headers, my_dir+ filename + ".csv");
	}
	
	protected void store_averages() throws IOException{
		String[] contents = {
				""+average_auc,
				""+average_precision0,
				""+average_precision1,
				""+average_recall0,
				""+average_recall1,
				""+average_fmeassure0,
				""+average_fmeassure1,
				""+average_accuracy,
				""+average_cost_effective,
				""+average_balanced_accuracy
		};
		rtcsv.write_contents(contents);
		rtcsv.close();
	}
	
	protected void show_average_info(){
		System.out.println("Average AUC: " + average_auc);
		System.out.println("Average Fmeasure0: " + average_fmeassure0);
		System.out.println("Average Fmeasure1: " + average_fmeassure1);
		System.out.println("accuracy: " + average_accuracy);
	}
}
