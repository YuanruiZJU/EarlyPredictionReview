package cs.zju.predictionmodels;

import cs.zju.utils.EvaluationState;
import cs.zju.utils.Preprocess;
import weka.classifiers.Classifier;
import weka.classifiers.CostMatrix;
import weka.classifiers.meta.MetaCost;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;


public class CostSensitivePredictionModel extends PredictionModel{
	public CostSensitivePredictionModel(String classifier_name){
		this.classifier_name = classifier_name;
	}
	
	private double learn_parameters(Instances DataSet) throws Exception{
		int positive = Preprocess.get_postive_sample_number(DataSet);
		int negative = DataSet.numInstances() - positive;
		double parameter = (double) negative / (double) positive;
		Instances subTrain = DataSet.trainCV(5, 0);
		Instances subTest = DataSet.testCV(5, 0);
		double cur_auc = 0;		
		return parameter;
	}
	
	public void Evaluate() throws Exception{
		initialize_numbers();
		new_rtcsv("cost_sensitive_" + classifier_name);
		for (int i = 0; i < 10; i++){
			Instances TrainSet = new DataSource(my_dir + i + "/" + trainFileName).getDataSet();
			Instances TestSet = new DataSource(my_dir + i + "/" + testFileName).getDataSet();
//			String cost_effect_path = my_dir + i + "/cost_effect.csv";
			
			
			TrainSet.setClassIndex(0);
			TestSet.setClassIndex(0);
			int train_positive = Preprocess.get_postive_sample_number(TrainSet);
			int train_negative = TrainSet.numInstances() - train_positive;
			CostMatrix cm = new CostMatrix(2);
			cm.setElement(0, 1, 1);
			cm.setElement(1, 0, ((double) train_negative) / ((double) train_positive));
			MetaCost metacost = new MetaCost();
			Classifier cla = get_classifier(classifier_name);
			metacost.setClassifier(cla);
			metacost.setCostMatrix(cm);
			evas = new EvaluationState();
			evas.setClaAndData(metacost, TrainSet, TestSet);
			update_average_numbers();
			evas.showInfoAndStore();
			evas.store(rtcsv);
//			evas.compute_all_cost_effective(metacost, TestSet, cost_effect_path);
		}
		getAvg();
		store_averages();		
		show_average_info();
	}
}
