package cs.zju.predictionmodels;

import cs.zju.utils.EvaluationState;
import cs.zju.utils.Preprocess;
import weka.classifiers.Classifier;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.supervised.instance.Resample;
import weka.filters.supervised.instance.SMOTE;

public class SmotePredictionModel extends PredictionModel{
	public SmotePredictionModel(String classifier_name){
		this.classifier_name = classifier_name;
	}
	
	public void Evaluate() throws Exception{
		initialize_numbers();
		new_rtcsv("smote_" + classifier_name);
		for (int i = 0; i < 10; i++){
			Instances TrainSet = new DataSource(my_dir + i + "/" + trainFileName).getDataSet();
			Instances TestSet = new DataSource(my_dir + i + "/" + testFileName).getDataSet();
			
			TrainSet.setClassIndex(0);
			TestSet.setClassIndex(0);
			
			SMOTE sm = new SMOTE();
			sm.setInputFormat(TrainSet);
			sm.setPercentage(50.0);
			sm.setNearestNeighbors(5);
			Instances SmoteInstances = Filter.useFilter(TrainSet,  sm);
			Resample re = new Resample();
			re.setInputFormat(SmoteInstances);
			re.setBiasToUniformClass(1);
			re.setSampleSizePercent(100.0);
			SmoteInstances = Filter.useFilter(SmoteInstances, re);
			int positive_smote = Preprocess.get_postive_sample_number(SmoteInstances);
			int negative_smote = SmoteInstances.numInstances() - positive_smote;
			Classifier cla = get_classifier(classifier_name);
			System.out.println("positive_smote: " + positive_smote + "  negative_smote: " + negative_smote);
			evas = new EvaluationState();
			evas.setClaAndData(cla, SmoteInstances, TestSet);
			update_average_numbers();
			evas.showInfoAndStore();
			evas.store(rtcsv);
		}
		getAvg();
		store_averages();		
		show_average_info();
	}
}
