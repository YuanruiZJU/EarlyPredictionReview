package cs.zju.predictionmodels;

import cs.zju.utils.EvaluationState;
import weka.classifiers.Classifier;
import weka.classifiers.meta.FilteredClassifier;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.supervised.instance.Resample;

public class NaivePredictionModel extends PredictionModel{
	public NaivePredictionModel(String classifier_name){
		this.classifier_name = classifier_name;
	}
	
	public void Evaluate() throws Exception{
		initialize_numbers();
		new_rtcsv("pure_" + classifier_name);
		for (int i = 0; i < 10; i++){
			Instances TrainSet = new DataSource(my_dir + i + "/" + trainFileName).getDataSet();
			Instances TestSet = new DataSource(my_dir + i + "/" + testFileName).getDataSet();
//			String cost_effect_path = my_dir + i + "/cost_effect.csv";
			TrainSet.setClassIndex(0);
			TestSet.setClassIndex(0);
			Classifier cla = get_classifier(classifier_name);
			evas = new EvaluationState();
			evas.setClaAndData(cla, TrainSet, TestSet);
			update_average_numbers();
			evas.showInfoAndStore();
			evas.store(rtcsv);
//			evas.compute_all_cost_effective(cla, TestSet, cost_effect_path);
		}
		getAvg();
		store_averages();		
		show_average_info();
	}
}
