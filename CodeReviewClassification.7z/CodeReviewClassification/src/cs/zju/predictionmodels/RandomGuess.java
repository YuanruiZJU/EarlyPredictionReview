package cs.zju.predictionmodels;


import weka.core.Instances;
import cs.zju.utils.ResultToCSV;
import weka.core.Instance;
import weka.core.converters.ConverterUtils.DataSource;


public class RandomGuess {
	
	private String my_dir;
	private int folds_num;
	private double recall;
	
	double avg_fmeassure1;
	double avg_precision1;
	double avg_fmeassure0;
	double avg_precision0;
	double avg_recall;
	
	public void set_project_set(String my_dir, int folds_num, double recall){
		this.my_dir = my_dir;
		this.folds_num = folds_num;
		this.recall = recall;
	}
	
	private void initialize_numbers(){
		avg_fmeassure1 = 0.0;
		avg_precision1 = 0.0;
		avg_fmeassure0 = 0.0;
		avg_precision0 = 0.0;
		avg_recall = 0.0;
	}
	
	public void Evaluate() throws Exception{
		initialize_numbers();
		String csv_path = my_dir + "constant_classifier.csv";
		if (recall == 0.5)
			csv_path = my_dir + "random_guess.csv";
		String[] headers = {"precision1", "fmeasure1", "precision0", "fmeassure0", "recall"};
		ResultToCSV csv_writer = new ResultToCSV(headers, csv_path);
		
		String[] headers2 = {"x", "y"};
		
		for(int i = 0; i < folds_num; i++){
			String dir = my_dir + i + "/";
			String train_file_path = dir + "train.arff";
			String test_file_path = dir + "test.arff";
			
			String cost_effect_csv_path = my_dir + i + "/cost_effect_random.csv";
			ResultToCSV csv_writer2 = new ResultToCSV(headers2, cost_effect_csv_path);
			
			Instances TrainSet = new DataSource(train_file_path).getDataSet();	
			Instances TestSet = new DataSource(test_file_path).getDataSet();
			TrainSet.setClassIndex(0);
			TestSet.setClassIndex(0);
			
			double positive = 0;
			double negative = 0;
			
			for(int j = 0; j < TestSet.numInstances(); j ++){
				Instance cur = TestSet.instance(j);
				if (cur.classValue() ==  1){
					positive ++;
				}else{
					negative ++;
				}
			}
			double positive_precision = positive / (positive + negative);
			double positive_f1 = 2 * recall * positive_precision /( positive_precision + recall);
			double negative_precision = negative / (positive + negative);
			double negative_f1 = 2 * recall * negative_precision / (negative_precision + recall);
			
			for (int k = 1; k <= 100; k ++){
				double temp_x = (double)k / 100.0;
				double temp_y = positive_precision;
//				if (temp_x * TestSet.numInstances() > positive)
//					temp_y = positive_precision * temp_x * TestSet.numInstances() / positive;				
				String[] cont = {
						"" + temp_x,
						"" + temp_y
				};
				csv_writer2.write_contents(cont);
			}
			csv_writer2.close();
			avg_fmeassure1 += positive_f1;
			avg_precision1 += positive_precision;
			avg_fmeassure0 += negative_f1;
			avg_precision0 += negative_precision;
			
			avg_recall += recall;			
			System.out.println("The" + i + "th dataset:");
			System.out.println("total:" + (positive + negative));
			System.out.println("positive: " + positive);
			System.out.println("positive precision: " + positive_precision);
			System.out.println("recall: " + recall);
			System.out.println("positive f1: " + positive_f1);
			System.out.println();
			
			String[] contents = {""+positive_precision,
					""+positive_f1,
					""+negative_precision,
					""+negative_f1,
					""+recall};
		
			csv_writer.write_contents(contents);
		}
		avg_fmeassure1 /= folds_num;
		avg_precision1 /= folds_num;
		avg_fmeassure0 /= folds_num;
		avg_precision0 /= folds_num;
		avg_recall /= folds_num;
		
		String[] contents = {
				""+avg_precision1,
				""+avg_fmeassure1,
				""+avg_precision0,
				""+avg_fmeassure0,
				""+avg_recall
		};
		csv_writer.write_contents(contents);
		csv_writer.close();
		System.out.println("avg_fmessure1: " + avg_fmeassure1);
		System.out.println("avg_precision1: " + avg_precision1);
		System.out.println("avg_fmeassure0: " + avg_fmeassure0);
		System.out.println("avg_precision0: " + avg_precision0);
		System.out.println("avg_recall: " + avg_recall);
	}
}
