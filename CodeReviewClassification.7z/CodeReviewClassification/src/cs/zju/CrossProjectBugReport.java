package cs.zju;

import cs.zju.utils.Preprocess;
import weka.classifiers.Classifier;
import weka.classifiers.CostMatrix;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.SMO;
import weka.classifiers.meta.MetaCost;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class CrossProjectBugReport {
	private static Instances sourceSet = null;
	
	public static void main (String[] args) throws Exception{
		System.out.println("............................");
		System.out.println("eclipse as training dataset\n");
	    ReadData("eclipse", false);
	    String sourceProject = "eclipse";
		Classifier cla = Build("RF", false);
		EvaluateOneMethodOneProject(cla, sourceProject, "netbeans", "mozilla", "firefox", "thunderbird");
		
		System.out.println("............................");
		System.out.println("netbeans as training dataset\n");
		ReadData("netbeans", false);
		cla = Build("RF", false);
		sourceProject = "netbeans";
		EvaluateOneMethodOneProject(cla, sourceProject, "eclipse", "mozilla", "firefox", "thunderbird");
		
		System.out.println("............................");
		System.out.println("mozilla as training dataset\n");
		ReadData("mozilla", false);
		cla = Build("RF", false);
		sourceProject = "mozilla";
		EvaluateOneMethodOneProject(cla, sourceProject, "eclipse", "netbeans", "firefox", "thunderbird");
		
		System.out.println("............................");
		System.out.println("firefox as training dataset\n");
		ReadData("firefox", false);
		cla = Build("RF", false);
		sourceProject = "firefox";
		EvaluateOneMethodOneProject(cla, sourceProject, "eclipse", "netbeans", "mozilla", "thunderbird");
		
		System.out.println("............................");
		System.out.println("thunderbird as training dataset\n");
		ReadData("thunderbird", false);
		cla = Build("RF", false);
		sourceProject = "thunderbird";
		EvaluateOneMethodOneProject(cla, sourceProject, "eclipse", "netbeans", "mozilla", "firefox");
	}
	
	public static void EvaluateOneMethodOneProject(Classifier cla, String sourceProject,
			String target1, String target2, String target3, String target4) throws Exception{
		Evaluate(cla, sourceProject, target1, false);
		Evaluate(cla, sourceProject, target2, false);
		Evaluate(cla, sourceProject, target3, false);
		Evaluate(cla, sourceProject, target4, false);
	}
	
	private static void ReadData(String sourceProject, boolean isMypaper) 
			throws Exception{
		if (isMypaper){
			System.out.println("read my_paper data");
			String sourcePath =  "C://discussion/" + sourceProject + ".arff";
			sourceSet = new DataSource(sourcePath).getDataSet();
			sourceSet.setClassIndex(0);
			sourceSet.deleteAttributeAt(1);
		} else{
			System.out.println("read baseline data");
			String sourcePath = "C://discussion/baseline/" + sourceProject + "/baseline.arff";
			sourceSet = new DataSource(sourcePath).getDataSet();
			sourceSet.setClassIndex(0);
			sourceSet.deleteAttributeAt(1);
		}
	}
	
	private static Classifier Build(String classifierName, boolean cost_sensitive) throws Exception{
		if (cost_sensitive){
			System.out.println("build classifier for COST-RF(our approach or COST-RFZ)");
			int train_positive = Preprocess.get_postive_sample_number(sourceSet);
			int train_negative = sourceSet.numInstances() - train_positive;
			CostMatrix cm = new CostMatrix(2);
			cm.setElement(0, 1, 1);
			cm.setElement(1, 0, ((double) train_negative) / ((double) train_positive));
			MetaCost metacost = new MetaCost();
			Classifier cla = new RandomForest();
			metacost.setClassifier(cla);
			metacost.setCostMatrix(cm);
			metacost.buildClassifier(sourceSet);
			return metacost;
		} else{
			if (classifierName.equals("SVM")){
				System.out.println("build classifier for SVMZ");
				Classifier cla = new SMO();
				cla.buildClassifier(sourceSet);
				return cla;
			} else {
				System.out.println("build classifier for RFZ");
				Classifier cla = new RandomForest();
				cla.buildClassifier(sourceSet);
				return cla;
			}
		}
	}
	
	private static void Evaluate(Classifier cla, String sourceProject, String targetProject,
			boolean isMypaper) throws Exception{
		System.out.println(targetProject + " as testing set.");
		String rootPath = "C://discussion/";
		
		String targetPath = null;
		if (isMypaper){
			targetPath = rootPath + "discussion2/" + sourceProject + "/" + targetProject + ".arff";
		} else{
			targetPath = rootPath + "baseline/" + targetProject + "/baseline.arff"; 
		}
		Instances targetSet = new DataSource(targetPath).getDataSet();
		targetSet.setClassIndex(0);
		targetSet.deleteAttributeAt(1);
		
		Evaluation eva = new Evaluation(sourceSet);
		eva.evaluateModel(cla, targetSet);
		
		double ba = 0.5 * eva.recall(0) + 0.5 * eva.recall(1);
		System.out.println("F1-faulty: " + eva.fMeasure(0));
		System.out.println("F1-valid: " + eva.fMeasure(1));
		System.out.println("balanced accuracy: " + ba);
		System.out.println("AUC: " + eva.areaUnderROC(0));
	}
}
