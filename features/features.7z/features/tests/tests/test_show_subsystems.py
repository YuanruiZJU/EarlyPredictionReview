import project_set

if __name__ == '__main__':
    p_set = project_set.deserialize_project_set('openstack')
    p_set.get_subsystems()