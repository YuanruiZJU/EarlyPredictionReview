import project_set
import code_review
import os



if __name__=="__main__":
    p_set = project_set.deserialize_sub_projects_map('eclipse')
    assert(isinstance(p_set, project_set.ProjectSet))
    review_data = p_set.review_data_set
    for review in review_data:
        assert(isinstance(review, code_review.CodeReview))
        modified_files = review.get_modified_files_num()
        modified_sub_systems = review.get_modified_subsystems_num()
        modifed_directories = review.get_num_modified_directories()
        if modified_files != modifed_directories or modified_files != modified_sub_systems or modifed_directories != modified_sub_systems:
            print "%s : %s : %s" % (review.get_modified_files_num(), review.get_num_modified_directories(), review.get_modified_subsystems_num())