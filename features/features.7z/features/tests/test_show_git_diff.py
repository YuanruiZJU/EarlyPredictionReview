import project_set
import global_variable

p_set_name = 'libreoffice'

sorted_change_map = project_set.deserialize_sorted_change_map(p_set_name)

change_number = 11221
change = sorted_change_map[change_number]

print len(change.files)

for f in change.files:
    print f.file_path, f.insertions, f.deletions

project = change.project
print change.status
path = global_variable.git_show_path + p_set_name + '/' + project + '/' + str(change_number) + '.txt'
git_show_file = open(path, 'r')
string = git_show_file.read()
git_show_file.close()

print string
