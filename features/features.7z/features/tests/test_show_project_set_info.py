from features import feature_utils
import os
import csv

sorted_change_map = feature_utils.get_sorted_change_map('eclipse', None)


def get_some_info():
    sub_project_info_map = {}
    len_change = len(sorted_change_map)
    print len_change
    num = 0
    i = 0
    no_modify_java_merged = 0
    no_modify_java_abandoned = 0
    java_merged = 0
    java_abandoned = 0
    has_java_change_num = 0

    merged = 0
    abandoned = 0

    while num < len_change:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1

        try:
            sub_project_info_map[ch.project]
        except KeyError:
            sub_project_info_map[ch.project] = {}
            sub_project_info_map[ch.project]['merged'] = 0
            sub_project_info_map[ch.project]['abandoned'] = 0

        insertions = 0
        deletions = 0
        has_java = False
        if ch.status == 'MERGED':
            merged += 1
            sub_project_info_map[ch.project]['merged'] += 1
        else:
            abandoned += 1
            sub_project_info_map[ch.project]['abandoned'] += 1
        for f in ch.files:
            extend = os.path.basename(f.file_path).split('.')[-1]
            if extend == 'java':
                insertions += f.insertions
                deletions += f.deletions
                has_java = True
        if has_java:
            has_java_change_num += 1
            if ch.status == 'MERGED' and insertions + deletions != 0:
                java_merged += 1
            elif ch.status == 'ABANDONED' and insertions + deletions != 0:
                java_abandoned += 1
        if insertions == 0 and deletions == 0:
            if ch.status == 'MERGED':
                no_modify_java_merged += 1
            else:
                no_modify_java_abandoned += 1

        i += 1
    print 'merged: %s, abandoned: %s' % (merged, abandoned)
    print 'no_modify_java_merged : %s, no_modify_java_abandoned: %s' % (no_modify_java_merged, no_modify_java_abandoned)
    print 'has_java_change: %s' % has_java_change_num
    print 'java_merged: %s, java_abandoned: %s' % (java_merged, java_abandoned)

    for key in sub_project_info_map.keys():
        print "%s: abandoned %s   merged   %s" % (key, sub_project_info_map[key]['abandoned'],
                                                  sub_project_info_map[key]['merged'])

    fields = ['project_name', 'abandoned', 'merged', 'ratio']
    csv_file = open('/Users/yuanruifan/Desktop/projects.csv', 'w')
    writer = csv.DictWriter(csv_file, fieldnames=fields)
    writer.writeheader()
    for key in sub_project_info_map.keys():
        abandoned_num = sub_project_info_map[key]['abandoned']
        merged_num = sub_project_info_map[key]['merged']
        row_dict = {'project_name': key,
                    'abandoned': abandoned_num,
                    'merged': merged_num,
                    'ratio': float(abandoned_num) / (float(abandoned_num + merged_num))}
        writer.writerow(rowdict=row_dict)


def check_not_consistent_change_status():
    not_consistent_merged = 0
    not_consistent_abandoned = 0
    import extract_features
    code_feature_map = extract_features.deserialize_file('/Users/yuanruifan/Desktop/MiningCodeReviews/binary_file/eclipse/features_maps/code_map')
    len_map = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        try:
            code_feature_map[i]
        except KeyError:
            if ch.status == 'MERGED':
                not_consistent_merged += 1
            else:
                not_consistent_abandoned += 1
        i += 1
    print not_consistent_abandoned
    print not_consistent_merged


def check_html_change_status():
    html_merged = 0
    html_abandoned = 0
    len_sorted = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i +=1
            continue

        num += 1
        for f in ch.files:
            file_path = f.file_path
            import os
            extend = os.path.basename(file_path).split('.')[-1]
            if extend == 'prefs':
                if ch.status == 'MERGED':
                    html_merged += 1
                else:
                    html_abandoned += 1
                break
        i += 1
    print html_merged, html_abandoned


def get_self_merged(status):
    len_sorted = len(sorted_change_map)
    print len_sorted
    i = 0
    num = 0
    merg = 0
    self_merged = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        if ch.status == status:
            merg+= 1
        num += 1
        if len(ch.reviewers) ==1 and ch.owner in ch.reviewers and ch.status == status:
            self_merged += 1
        i += 1

    print self_merged
    print merg


def get_project_file_info():
    import os
    len_sorted = len(sorted_change_map)
    print len_sorted
    i = 0
    num = 0

    language_num = 0
    merge = 0
    abandon = 0
    #extends = ['cxx', 'cpp', 'c', 'hpp', 'h', 'hxx']
    #extends = ['py']
    extends = ['java']
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1

        if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
            i += 1
            continue

        all_has_extend = True

        for f in ch.files:
            if f.insertions + f.deletions == 0:
                continue
            if os.path.basename(f.file_path).split('.')[-1] not in extends:
                #print os.path.basename(f.file_path).split('.')[-1]
                all_has_extend = False
        if all_has_extend:
            if ch.status == 'MERGED':
                merge += 1
            else:
                abandon += 1
            language_num += 1
        i += 1

    print language_num
    print merge
    print abandon



get_some_info()

# get_self_merged('MERGED')
# get_self_merged('ABANDONED')

# get_project_file_info()
