import project_set
import os
sorted_change_map = project_set.deserialize_sorted_change_map('libreoffice')

global_files = {}

extend = {}

file_num = 0

extend_without_text = set()

for number in sorted_change_map.keys():
    files = sorted_change_map[number].files
    for f in files:
        file_path = f.file_path
        try:
            global_files[file_path]
        except KeyError:
            global_files[file_path] = True
            this_extend = os.path.basename(file_path).split('.')[-1]
            try:
                extend[this_extend] += 1
            except KeyError:
                extend[this_extend] = 1

for ext in extend.keys():
    print "%s : %s" % (ext, extend[ext])

print len(extend.keys())