import project_set

sub_project_people_map = {}

sorted_change_map = project_set.deserialize_sorted_change_map('eclipse')

sub_project_map = project_set.deserialize_sub_projects_map('eclipse')

for number in sorted_change_map.keys():
    ch = sorted_change_map[number]
    project = ch.project
    owner = ch.owner
    reviewers = ch.reviewers
    try:
        sub_project_people_map[project]
    except KeyError:
        sub_project_people_map[project] = set()

    sub_project_people_map[project].add(owner)
    for r in reviewers:
        sub_project_people_map[project].add(r)


for key in sub_project_people_map.keys():
    print '%s : %s %s' % (key, len(sub_project_people_map[key]), len(sub_project_map[key].refs))