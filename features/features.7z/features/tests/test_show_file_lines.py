import project_set
import os

sorted_change_map = project_set.deserialize_sorted_change_map('openstack')

lines = []

projects = set()
num_change = 0


def get_file_lines():
    global num_change
    len_sorted = len(sorted_change_map)
    i = 0
    num = 0
    languages = ['py']
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
            i += 1
            continue
        if len(ch.reviewers) == 0:
            i += 1
            continue
        if ch.status == 'MERGED':
            lines_modify = 0
            has_other_file = False
            for f in ch.files:
                if f.insertions + f.deletions == 0:
                    continue
                extend = os.path.basename(f.file_path).split('.')[-1]
                if extend not in languages:
                    has_other_file = True
                lines_modify += f.insertions + f.deletions
            if not has_other_file:
                projects.add(ch.project)
                num_change += 1
                lines.append(lines_modify)
        i += 1

get_file_lines()
print lines
lines.sort()
index = int(float(len(lines)) * 0.9)
print lines[index]
index = int(float(len(lines)) * 0.99)
print lines[index]
index = int(float(len(lines)) * 0.95)
print lines[index]
print len(projects)
print num_change
# candidate_lines = []
# for i in range(1,31):
#     candidate_lines.append(i * 50)
#
# candidate_lines_map = {}
# for line in candidate_lines:
#     candidate_lines_map[line] = 0
#
# len_lines = len(lines)
# i = 0
# while i < len_lines:
#     for line in candidate_lines:
#         if line > lines[i]:
#             candidate_lines_map[line] += 1
#     i += 1
#
# for line in candidate_lines:
#     print '%s: %s' % (line, candidate_lines_map[line])
