from features import feature_utils
import datetime

sorted_change_map = feature_utils.get_sorted_change_map('libreoffice')

days_reviews = {}
years = ['2009','2010','2011', '2012', '2013','2014', '2015', '2016']

years_reviews = {}
def get_days():
    sorted_change_map = feature_utils.get_sorted_change_map('libreoffice')

    days_reviews = {}
    years = ['2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016']

    years_reviews = {}
    i = 0
    num = 0
    while num < len(sorted_change_map):
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        today = ch.created.split(' ')[0]
        year_i = int(today.split('-')[0])
        month_i = int(today.split('-')[1])
        day_i = int(today.split('-')[2])
        today = datetime.datetime(year_i, month_i, day_i)
        if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
            i += 1
            continue
        try:
            days_reviews[today]
        except KeyError:
            days_reviews[today] = {}
        for r in ch.reviewers:
            if r != ch.owner:
                try:
                    days_reviews[today][r]
                except KeyError:
                    days_reviews[today][r] = 0
                days_reviews[today][r] += 1
        i += 1


def max_day():
    max_avg = 0
    for day in days_reviews.keys():
        max = 0
        for r in days_reviews[day].keys():
            if days_reviews[day][r] > max:
                max = days_reviews[day][r]
        max_avg += max
        print max

    print "avg: %s" % (max_avg / len(days_reviews))

def get_years():
    i = 0
    num = 0
    global years_reviews
    for year in years:
        years_reviews[year] = 0
    while num < len(sorted_change_map):
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
            i += 1
            continue
        year = ch.created.split('-')[0]
        if year in years:
            years_reviews[year] += 1
        i += 1

# get_days()
# max_day()


def get_week_avg():
    start_day = datetime.datetime(2015, 1, 1)
    next_day = start_day
    get_days()
    week_num = 0
    avg_sum = 0
    reviewers_n = 0
    while start_day < datetime.datetime(2016, 1, 1):
        reviewers = set()
        reviewers_review = {}
        review_people_num = 0
        week_num += 1
        while (next_day - start_day).days < 7:
            try:
                days_reviews[next_day]
            except KeyError:
                next_day = next_day + datetime.timedelta(days=1)
                continue
            for r in days_reviews[next_day].keys():
                review_people_num += days_reviews[next_day][r]
                reviewers.add(r)
                if reviewers_review.has_key(r):
                    reviewers_review[r] += days_reviews[next_day][r]
                else:
                    reviewers_review[r] = days_reviews[next_day][r]
            next_day = next_day + datetime.timedelta(days=1)

        start_day = next_day
        reviewer_num = len(reviewers)
        if reviewer_num == 0:
            continue
        # print reviewer_num
        for r in reviewers:
            if reviewers_review[r] < 2:
                review_people_num -= reviewers_review[r]
                reviewer_num -= 1
        # print review_people_num
        reviewers_n += reviewer_num
        avg_per_week = float(review_people_num) / float(reviewer_num)
        print "%s : %s : %s" % (week_num, reviewer_num, avg_per_week)
        avg_sum += avg_per_week

    print avg_sum / week_num
    print reviewers_n / week_num


def get_max_ratio():
    start_day = datetime.datetime(2015, 1, 1)
    next_day = start_day
    get_days()
    week_num = 0
    day = 0
    while next_day < datetime.datetime(2016, 1, 1):
        max = 0
        try:
            days_reviews[next_day]
        except KeyError:
            next_day = next_day + datetime.timedelta(days=1)
            continue
        for r in days_reviews[next_day].keys():
            if days_reviews[next_day][r] > max:
                max = days_reviews[next_day][r]
        if max > 15:
            day += 1
        next_day = next_day + datetime.timedelta(days=1)
    print day
    print float(day) / 365.0

# get_week_avg()
get_max_ratio()
