from features import feature_utils
import datetime

reviewer_change_num_map = {}
reviewer_change_map = {}

def get_reviewers(p_set_name):
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name)
    i = 0
    num = 0
    while num < len(sorted_change_map):
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        if ch.created.split('-')[0] == '2015':
            if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
                i += 1
                continue
            else:
                for r in ch.reviewers:
                    if r != ch.owner:
                        try:
                            reviewer_change_num_map[r]
                        except KeyError:
                            reviewer_change_num_map[r] = 0
                        reviewer_change_num_map[r] += 1

                        try:
                            reviewer_change_map[r]
                        except KeyError:
                            reviewer_change_map[r] = set()
                        reviewer_change_map[r].add(ch.change_number)
        i += 1


def count_review_by_people(p_set_name):
    get_reviewers(p_set_name)
    print len(reviewer_change_num_map)
    sorted_reviewers = sorted(reviewer_change_num_map.values())
    len_value = len(reviewer_change_num_map.values())
    compute_len = len_value * 0.9
    print len_value
    print compute_len
    total_number = 0
    little_number = 0
    i = 0
    while i < len_value:
        total_number += sorted_reviewers[i]
        if i < compute_len:
            little_number += sorted_reviewers[i]
        i += 1

    print little_number
    print total_number
    print float(total_number - little_number) / float(total_number)


def count_real_review(p_set_name, ratio=0.85):
    get_reviewers(p_set_name)
    reviews = set()
    for r in reviewer_change_map.keys():
        reviews |= reviewer_change_map[r]
    sorted_reviewers = sorted(reviewer_change_num_map.items(), key=lambda item:item[1])
    len_reviewers = len(sorted_reviewers)

    n_changes = len(reviews)
    large_changes = set()
    threshold = len_reviewers * ratio
    i = len_reviewers - 1
    while i >= threshold:
        r = sorted_reviewers[i][0]
        large_changes |= reviewer_change_map[r]
        i -= 1
    print len(large_changes)
    print n_changes
    print float(len(large_changes)) / n_changes

# count_review_by_people()
# count_real_review()


def get_core_reviewers(p_set_name):
    get_reviewers(p_set_name)
    sorted_reviewers = sorted(reviewer_change_num_map.items(), key=lambda item: item[1])
    i = 0
    only_one_reviewer = 0
    while i < len(sorted_reviewers):
        if sorted_reviewers[i][1] == 1:
            only_one_reviewer += 1
        i += 1

    core_reviewers = set()
    len_reviewers = len(sorted_reviewers)
    # threshold = len_reviewers * 0.8
    # i = len_reviewers - 1
    # while i >= threshold:
    #     core_reviewers.add(sorted_reviewers[i][0])
    #     i -= 1
    reviews = set()
    for r in reviewer_change_map.keys():
        reviews |= reviewer_change_map[r]
    i = len_reviewers - 1
    large_review_reqs = set()
    while i >= 0:
        r = sorted_reviewers[i][0]
        large_review_reqs |= reviewer_change_map[r]
        core_reviewers.add(r)
        if len(large_review_reqs) >= 0.8 * len(reviews):
            break
        i -= 1
    print i
    print float(len_reviewers - i) / float(len_reviewers - only_one_reviewer)
    return core_reviewers


def get_everyday_change(p_set_name):
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name)
    days_reviews = {}
    i = 0
    num = 0
    while num < len(sorted_change_map):
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        today = ch.created.split(' ')[0]
        year_i = int(today.split('-')[0])
        month_i = int(today.split('-')[1])
        day_i = int(today.split('-')[2])
        if year_i != 2015:
            i += 1
            continue
        today = datetime.datetime(year_i, month_i, day_i)
        if len(ch.reviewers) == 1 and ch.owner in ch.reviewers:
            i += 1
            continue
        try:
            days_reviews[today]
        except KeyError:
            days_reviews[today] = {}
        for r in ch.reviewers:
            if r != ch.owner:
                try:
                    days_reviews[today][r]
                except KeyError:
                    days_reviews[today][r] = 0
                days_reviews[today][r] += 1
        i += 1
    return days_reviews


def get_heavy_reviewer(p_set_name):
    core_reviewers = get_core_reviewers(p_set_name)
    print len(core_reviewers)
    days_reviews = get_everyday_change(p_set_name)

    large_reviewers = set()
    daily_large_reviewers = {}
    # for day in day_reviews.keys():
    #     for r in day_reviews[day].keys():
    #         if day_reviews[day][r] >= 20 and r in core_reviewers:
    #             large_reviewers.add(r)
    start_day = datetime.datetime(2015, 1, 1)
    next_day = start_day
    while start_day < datetime.datetime(2016, 1, 1):
        reviewers = set()
        reviewers_review = {}
        review_people_num = 0
        while (next_day - start_day).days < 7:
            try:
                days_reviews[next_day]
            except KeyError:
                next_day = next_day + datetime.timedelta(days=1)
                continue
            for r in days_reviews[next_day].keys():
                review_people_num += days_reviews[next_day][r]
                reviewers.add(r)
                if days_reviews[next_day][r] >= 20 and r in core_reviewers:
                    try:
                        daily_large_reviewers[r]
                    except KeyError:
                        daily_large_reviewers[r] = 0
                    daily_large_reviewers[r] += 1
                if reviewers_review.has_key(r):
                    reviewers_review[r] += days_reviews[next_day][r]
                else:
                    reviewers_review[r] = days_reviews[next_day][r]
            next_day = next_day + datetime.timedelta(days=1)
            if next_day >= datetime.datetime(2016,1,1):
                break
        start_day = next_day
        reviewer_num = len(reviewers)
        if reviewer_num == 0:
            continue
            # print reviewer_num
        for r in reviewers:
            if reviewers_review[r] >= 20 and r in core_reviewers:
                large_reviewers.add(r)
    print len(large_reviewers)
    print '%s daily large reviewers' % len(daily_large_reviewers)
    sorted_daily = sorted(daily_large_reviewers.items(), key=lambda item: item[1])
    print sorted_daily[-1][1]
    print sorted_daily[-1][0]


if __name__ == '__main__':
    p_set_name = 'openstack'
    # get_core_reviewers(p_set_name)
    # count_real_review(p_set_name, 0.8)
    # get_core_developer(p_set_name)
    # count_real_review(p_set_name, 0.9)
    get_heavy_reviewer(p_set_name)
