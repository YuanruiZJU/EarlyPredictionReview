import project_set

p_set_name = 'libreoffice'

message_map = project_set.deserialize_message_map(p_set_name)
sorted_change_map = project_set.deserialize_sorted_change_map(p_set_name)

len_sorted = len(sorted_change_map)
i = 0
num = 0
number = 0
while num < len_sorted:
    try:
        ch = sorted_change_map[i]
    except KeyError:
        i += 1
        continue
    num += 1
    # print i
    if 'NOT SUBMIT' in ch.subject:
        number += 1
        print ch.subject
    i += 1

print number
