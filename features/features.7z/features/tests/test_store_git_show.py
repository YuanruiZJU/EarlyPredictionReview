import project_set
import sub_project

if __name__=="__main__":
    sub_project_map = project_set.deserialize_sub_projects_map('eclipse')
    sub_p = sub_project_map['egit/egit']
    assert(isinstance(sub_p, sub_project.SubProject))
    sub_p.store_git_show_files()