import revision
import project_set
import utils


class SimpleCodeReview:
    def __init__(self, code_review_data):
        assert(isinstance(code_review_data, CodeReview))
        self.status = code_review_data.status
        self.created = code_review_data.created
        self.updated = code_review_data.updated
        self.change_number = code_review_data.get_change_no()
        self.insertions = code_review_data.insertions
        self.deletions = code_review_data.deletions
        self.owner = code_review_data.owner
        self.reviewers = code_review_data.reviewers
        self.project = code_review_data.project
        self.branch = code_review_data.branch
        self.subject = code_review_data.subject
        self.files = code_review_data.first_revision.files

        self.cached_subsystems = None
        self.cached_directories = None

    @property
    def subsystems(self):
        if self.cached_subsystems is not None:
            return self.cached_subsystems
        else:
            self.cached_subsystems = set()
            for f in self.files:
                if f.insertions + f.deletions == 0:
                    continue
                subsys = utils.subsystem_of(f.file_path)
                self.cached_subsystems.add((self.project, subsys))

            return self.cached_subsystems

    @property
    def directories(self):
        if self.cached_directories is not None:
            return self.cached_directories
        else:
            self.cached_directories = set()
            for f in self.files:
                if f.insertions + f.deletions == 0:
                    continue
                directory = utils.directory_of(f.file_path)
                self.cached_directories.add(directory)
            return self.cached_directories

    def get_language_num(self):
        languages = ['java', 'c', 'h', 'cxx', 'hxx', 'cpp', 'hpp',
                  'rb', 'py', 'javascript', 'bash', 'sh', 'go', 'html',
                  'php',' js']
        extend_set = set()
        c_set = set()
        c_set.add('c')
        c_set.add('h')
        c_set.add('cxx')
        c_set.add('hxx')
        c_set.add('cpp')
        c_set.add('hpp')
        javascript = set()
        javascript.add('javascript')
        javascript.add('js')
        bash_set = set()
        bash_set.add('bash')
        bash_set.add('sh')
        for f in self.files:
            if f.insertions + f.deletions == 0:
                continue
            import os
            extend = os.path.basename(f.file_path).split('.')[-1]
            if extend in languages:
                extend_set.add(extend)
        if len(c_set & extend_set) > 0:
            extend_set -= c_set
            extend_set.add('c')
        if len(javascript & extend_set) > 0:
            extend_set -= javascript
            extend_set.add('js')
        if len(bash_set & extend_set) > 0:
            extend_set -= bash_set
            extend_set.add('bash')

        return len(extend_set)

    def get_file_type_num(self):
        extend_set = set()
        for f in self.files:
            if f.insertions + f.deletions == 0:
                continue
            import os
            extend = os.path.basename(f.file_path).split('.')[-1]
            extend_set.add(extend)
        return len(extend_set)


class PersonalCodeReview:
    def __init__(self, simple_code_review):
        assert(isinstance(simple_code_review, SimpleCodeReview))
        self.change_number = simple_code_review.change_number


class CodeReview:

    def __init__(self, project_set_instance, change_dict):
        assert(isinstance(project_set_instance, project_set.ProjectSet))
        # self.id = change_dict['id']
        self.status = change_dict['status']
        self._number = change_dict['_number']
        try:
            self.insertions = change_dict['insertions']
            self.deletions = change_dict['deletions']
        except KeyError:
            self.insertions = 0
            self.deletions = 0
        self.owner = change_dict['owner']['_account_id']
        self.project = change_dict['project']
        self.branch = change_dict['branch']
        self.subject = change_dict['subject']
        self.first_revision = None
        self.reviewers = set()
        try:
            for r in project_set_instance.change_reviewers[self._number]:
                if r in project_set_instance.non_natural_human:
                    continue
                self.reviewers.add(r)
        except KeyError:
            pass

        self.created = change_dict['created']
        self.updated = change_dict['updated']
        from features import feature_utils
        try:
            message_created = change_dict['messages'][0]['date']
            if feature_utils.delta_days(message_created, self.created)<0:
                self.created = message_created
        except:
            pass

        messages_number = len(change_dict['messages'])
        i = 0
        while i < messages_number:
            this_message = change_dict['messages'][i]
            try:
                author_dict = this_message['author']
            except KeyError:
                i += 1
                continue
            author_id = author_dict['_account_id']
            try:
                author_name = author_dict['name']
            except KeyError:
                i += 1
                continue
            if 'CI' in author_name.split(' ') or \
                            author_name == 'jenkins' or \
                            author_name == 'Jenkins' or \
                            author_name == 'Eclipse Genie':
                try:
                    self.reviewers.remove(author_id)
                    project_set_instance.non_natural_human.add(author_id)
                except KeyError:
                    pass
            i += 1
        # self.change_id = change_dict['change_id']
        self.set_first_revision(change_dict['revisions'])

    def is_real_change_code(self):
        if self.first_revision is None:
            return False
        if len(self.first_revision.files) == 0:
            return False
        return True

    def get_change_no(self):
        return self._number

    def set_first_revision(self, revisions_dict):
        assert(isinstance(revisions_dict, dict))
        least_number = 20
        temp_id = ""
        for rev_id in revisions_dict.keys():
            if revisions_dict[rev_id]['_number'] < least_number:
                least_number = revisions_dict[rev_id]['_number']
                temp_id = rev_id
        try:
            rev_dict = revisions_dict[temp_id]
            first_r = revision.Revision(temp_id, rev_dict)
            self.first_revision = first_r
        except KeyError:
            self.first_revision = None

    def get_message(self):
        if self.first_revision is not None:
            assert(isinstance(self.first_revision, revision.Revision))
            return self.first_revision.message
        else:
            return ""
