import global_variable
import code_review
import sub_project
import utils

import time
import string
import os
import requests
import thread

num_change_data_per_slice = global_variable.num_change_data_per_slice


def deserialize_file(project_set_name, file_name, sub_project_name=None):
    if sub_project_name is not None:
        file_path = global_variable.serialize_file_path + project_set_name + '/' + \
            sub_project_name + '/' + file_name
    else:
        file_path = global_variable.serialize_file_path + project_set_name + '/' + file_name
        print os.path.exists(file_path)
    return utils.deserialize_file(file_path)


def deserialize_project_set(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + '/serialize_file'
    return utils.deserialize_file(file_path)


def deserialize_sub_projects_map(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + "/sub_projects_map"
    return utils.deserialize_file(file_path)


def deserialize_sorted_change_map(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + '/sorted_change_map'
    return utils.deserialize_file(file_path)


def deserialize_people_change_map(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + '/people_change_map'
    return utils.deserialize_file(file_path)


def deserialize_filtered_sub_projects(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + '/filtered_sub_projects'
    return utils.deserialize_file(file_path)


def deserialize_message_map(project_set_name):
    file_path = global_variable.serialize_file_path + project_set_name + '/message_map'
    return utils.deserialize_file(file_path)


def quick_serialize_sub_projects_map(project_set_name, sub_project_map):
    file_path = global_variable.serialize_file_path + project_set_name + "/sub_projects_map"
    utils.serialize_file(file_path, sub_project_map)


def set_https_url(sub_project_map, key):
    sub_p = sub_project_map[key]
    if sub_p.git_url[0:3] == 'git':
        sub_p.git_url = 'http' + sub_p.git_url[3:]
    return sub_project_map


def get_all_reviewer_file_paths(status, reviewer_path):
    path = reviewer_path + status + '/'
    file_list = []
    files = os.listdir(path)

    for f in files:
        if os.path.isdir(path+f):
            continue
        try:
            string.atoi(f)
        except:
            continue
        if os.path.isfile(path+f):
            file_list.append(path+f)
    return file_list


class ProjectSet:
    def __init__(self, project_set, filter_changes=False):
        """
        :param project_set: name of the project set
        """
        self.name = project_set
        self.change_reviewers = {}
        self.review_data_set = []

        self.get_reviewers_from_cache_file()
        self.non_natural_human = set()
        self.parse_all_change_data(filter_changes=filter_changes)

    def get_change_number(self, status):
        path = global_variable.code_review_path + self.name + '/' + status + '/'
        i = 0
        while os.path.exists(path + '%s-%s.json' % (i, i+num_change_data_per_slice-1)):
            i += num_change_data_per_slice
        return i

    def get_reviewers_from_cache_file(self):
        """
        Get reviewers of changes from cached file.
        :return:
        """
        reviewer_path = global_variable.reviewer_dir_path + self.name + '/'
        merged_file_list = get_all_reviewer_file_paths('merged', reviewer_path)
        abandoned_file_list = get_all_reviewer_file_paths('abandoned', reviewer_path)
        file_list = merged_file_list + abandoned_file_list

        for file_path in file_list:
            file_obj = open(file_path, 'r')
            change_reviewers = file_obj.readlines()
            for ch_r in change_reviewers:
                if ':' not in ch_r:
                    continue
                # Every line has same form: 123:[1,4,5]
                change_number = string.atoi(ch_r.split(':')[0])
                reviewers = utils.parse_json_str(ch_r.split(':')[1][:-1])
                self.change_reviewers[change_number] = reviewers

    def parse_change_by_status(self, status, filter_changes=False):
        change_number_set = set()
        i = 0
        change_data_number = self.get_change_number(status)
        while i < change_data_number:
            print i
            file_path = global_variable.code_review_path + self.name+'/' + \
                        status+'/' + '%s-%s.json' % (i, i+99)
            change_data_slice = utils.parse_json_file(file_path)

            for change_data in change_data_slice:
                _number = change_data['_number']
                if change_number_set.__contains__(_number):
                    continue
                c_review = code_review.CodeReview(self, change_data)
                # If no revision in this code_review, ignore this code review.
                if c_review.first_revision is None:
                    continue
                # If filter_changes=True, filter changes without file changed
                if filter_changes and not c_review.is_real_change_code():
                    continue
                self.review_data_set.append(c_review)
            i = i + num_change_data_per_slice

    def parse_all_change_data(self, filter_changes=False):
        self.parse_change_by_status('merged', filter_changes=filter_changes)
        self.parse_change_by_status('abandoned', filter_changes=filter_changes)
        print len(self.review_data_set)
        print len(self.non_natural_human)

    def serialize(self):
        file_path = global_variable.serialize_file_path + self.name + '/serialize_file'
        utils.serialize_file(file_path, self)

    def serialize_sub_projects_map(self):
        file_path = global_variable.serialize_file_path + self.name + "/sub_projects_map"
        utils.serialize_file(file_path, self.sub_project_map)

    def serialize_sorted_change_map(self, filter_changes=False, filter_abandoned_ratio=0):
        file_path = global_variable.serialize_file_path + self.name + '/sorted_change_map'
        utils.serialize_file(file_path, self.sorted_change_map(filter_changes=filter_changes,
                                                               filter_abandoned_ratio=filter_abandoned_ratio))

    def serialize_people_change_map(self):
        file_path = global_variable.serialize_file_path + self.name + '/people_change_map'
        utils.serialize_file(file_path, self.people_change_map)

    def serialize_filtered_sub_projects(self):
        file_path = global_variable.serialize_file_path + self.name + '/filtered_sub_projects'
        utils.serialize_file(file_path, self.filtered_sub_projects)

    def serialize_message_map(self):
        file_path = global_variable.serialize_file_path + self.name + '/message_map'
        utils.serialize_file(file_path, self.message_map)

    @staticmethod
    def filter_sub_project_by_abandon_ratio(sorted_change_map, ratio):
        len_sorted = len(sorted_change_map)
        i = 0
        num = 0
        sub_project_map = {}
        print "first loop"
        while num < len_sorted:
            try:
                ch = sorted_change_map[i]
            except KeyError:
                i += 1
                continue
            num += 1
            project = ch.project
            try:
                sub_project_map[project]
            except KeyError:
                sub_project_map[project] = {}
                sub_project_map[project]['abandoned'] = 0
                sub_project_map[project]['merged'] = 0
            if ch.status == 'MERGED':
                sub_project_map[project]['merged'] += 1
            else:
                sub_project_map[project]['abandoned'] += 1
            i += 1
        for key in sub_project_map.keys():
            sub_project_map[key]['ratio'] = float(sub_project_map[key]['abandoned']) / float(sub_project_map[key]['merged'])

        print "second loop"
        num = 0
        i = 0
        result_change_map = {}
        while num < len_sorted:
            try:
                ch = sorted_change_map[i]
            except KeyError:
                i += 1
                continue
            num += 1
            if sub_project_map[ch.project]['ratio'] < ratio:
                i += 1
                continue
            result_change_map[ch.change_number] = ch
            i += 1
        return result_change_map

    @property
    def sub_project_map(self):
        if hasattr(self, 'cached_sub_project_map') and self.cached_sub_project_map != None:
            return self.cached_sub_project_map
        else:
            sub_project_map = {}
            append_last_changes = []
            for change_data in self.review_data_set:
                assert(isinstance(change_data, code_review.CodeReview))
                project = change_data.project
                try:
                    sub_project_instance = sub_project_map[project]
                except KeyError:
                    sub_project_map[project] = sub_project.SubProject(self, project)
                    sub_project_instance = sub_project_map[project]
                    assert(isinstance(sub_project_instance, sub_project.SubProject))
                    sub_project_instance.git_url = change_data.first_revision.fetch.url
                    sub_project_instance.make_project_dirs()

                assert(isinstance(sub_project_instance, sub_project.SubProject))
                append_to_last = False
                message = change_data.get_message()
                if change_data.status == 'ABANDONED':
                    if "NOT MERGE" in message:
                        append_to_last = True
                    if " not merge " in message:
                        append_to_last = True
                    if " Not Merge " in message:
                        append_to_last = True
                    if ("test " in message) or ("TEST " in message) or ("Test " in message):
                        append_to_last = True
                try:
                    self.change_reviewers[change_data.get_change_no()]
                except KeyError:
                    append_to_last = True
                if not append_to_last:
                    sub_project_instance.refs.append(change_data.first_revision.fetch.ref)
                else:
                    append_last_changes.append(change_data)

            for change_data in append_last_changes:
                project = change_data.project
                sub_project_map[project].refs.append(change_data.first_revision.fetch.ref)

            self.cached_sub_project_map = sub_project_map
            return self.cached_sub_project_map

    @property
    def filtered_sub_projects(self):
        if hasattr(self, 'cached_filtered_sub_projects') and self.cached_filtered_sub_projects != None:
            return self.cached_filtered_sub_projects
        else:
            threshold = 200
            self.cached_filtered_sub_projects = []
            projects_merged_changes_map = {}
            i = 0
            for ch in self.review_data_set:
                print i
                i += 1
                if ch.status == 'MERGED':
                    try:
                        projects_merged_changes_map[ch.project] += 1
                    except KeyError:
                        projects_merged_changes_map[ch.project] = 1
            for p in projects_merged_changes_map.keys():
                if projects_merged_changes_map[p] > threshold:
                    if 'document' in p:
                        print p
                    self.cached_filtered_sub_projects.append(p)
            return self.cached_filtered_sub_projects

    def sub_project_sorted_change_maps(self, project_name, root_project=False):
        my_path = global_variable.serialize_file_path + self.name + '/' + \
            project_name + '/'
        sub_project_change_map_path = my_path + 'sorted_change_map'
        sub_project_people_map_path = my_path + 'people_change_map'
        sub_project_message_map_path = my_path + 'message_map'
        if not os.path.exists(my_path):
            os.makedirs(my_path)
        sorted_changes = {}
        personal_change_map = {}
        message_map = {}
        i = 0
        for ch in self.review_data_set:
            print i
            i += 1
            assert(isinstance(ch, code_review.CodeReview))
            subject = ch.subject
            if "NOT MERGE" in subject or "not merge" in subject:
                continue
            if "IGNORE" in subject:
                continue
            for non_human in self.non_natural_human:
                try:
                    ch.reviewers.remove(non_human)
                except KeyError:
                    pass
            if (not root_project and ch.project == project_name) or \
                    (root_project and ch.project.split('/')[0] == project_name):
                change_number = ch.get_change_no()
                sorted_changes[change_number] = code_review.SimpleCodeReview(ch)
                message_map[change_number] = ch.get_message()

        len_sub_project = len(sorted_changes)
        i = 1
        num = 0
        while num < len_sub_project:
            try:
                simple_ch = sorted_changes[i]
            except KeyError:
                i += 1
                continue
            num += 1
            i += 1
            owner = simple_ch.owner
            try:
                personal_change_map[owner]
            except KeyError:
                personal_change_map[owner] = []
            personal_change_map[owner].append(code_review.PersonalCodeReview(simple_ch))

        utils.serialize_file(sub_project_change_map_path, sorted_changes)
        utils.serialize_file(sub_project_people_map_path, personal_change_map)
        utils.serialize_file(sub_project_message_map_path, message_map)

    def sorted_change_map(self, filter_changes=False, filter_abandoned_ratio=0):
        if hasattr(self, 'cached_sorted_change_map') and \
                        self.cached_sorted_change_map is not None:
            return self.cached_sorted_change_map
        else:
            sorted_changes = {}
            for ch in self.review_data_set:
                assert(isinstance(ch, code_review.CodeReview))
                if filter_changes and not ch.is_real_change_code():
                    continue
                if filter_changes and ch.project not in self.filtered_sub_projects:
                    continue
                # If the author explicitly claim that it cannot be merged, ignore it.
                subject = ch.subject
                if "NOT MERGE" in subject or "not merge" in subject:
                    continue
                if "IGNORE" in subject:
                    continue
                # remove non human reviewers.
                for non_human in self.non_natural_human:
                    try:
                        ch.reviewers.remove(non_human)
                    except KeyError:
                        pass
                change_number = ch.get_change_no()
                sorted_changes[change_number] = code_review.SimpleCodeReview(ch)
            print "start filter projects by abandon ratio"
            self.cached_sorted_change_map = self.filter_sub_project_by_abandon_ratio(sorted_changes,
                                                                                     filter_abandoned_ratio)
        return self.cached_sorted_change_map

    @property
    def people_change_map(self):
        if hasattr(self, 'cached_people_change_map') and \
                        self.cached_people_change_map is not None:
            return self.cached_people_change_map
        else:
            self.cached_people_change_map = {}
            sorted_map = self.sorted_change_map()
            n_changes = len(sorted_map)
            i = 0
            num = 0
            while num < n_changes:
                try:
                    ch = sorted_map[i]
                    num += 1
                    owner = ch.owner
                    personal_change_data = code_review.PersonalCodeReview(ch)
                    try:
                        self.cached_people_change_map[owner]
                    except KeyError:
                        self.cached_people_change_map[owner] = []
                    self.cached_people_change_map[owner].append(personal_change_data)
                except KeyError:
                    pass
                i += 1
            return self.cached_people_change_map

    @property
    def message_map(self):
        if hasattr(self, 'cached_message_map') and self.cached_message_map is not None:
            return self.cached_message_map
        else:
            self.cached_message_map = {}
            for change_data in self.review_data_set:
                assert(isinstance(change_data, code_review.CodeReview))
                message = change_data.get_message()
                number = change_data.get_change_no()
                self.cached_message_map[number] = message
            return self.cached_message_map

    def get_reviewers_from_network(self, change_dict, review_file_name):
        """
        Get changes' reviewers using RESTful API
        """
        complete_change_id = change_dict['id']
        reviewer_url = global_variable.change_urls[self.name]+complete_change_id+"/reviewers/"
        fail = True
        reviewerStr = []
        while fail:
            try:
                reviewerStr = requests.get(reviewer_url).content[4:]
                fail = False
            except:
                time.sleep(60)

        reviewers_data = []
        try:
            reviewers_data = utils.parse_json_str(reviewerStr)
        except:
            print reviewerStr
            print "cannot be parsed by simple json!"

        # If no reviewers , just ignore this change or has exception
        if len(reviewers_data) == 0:
            return

        result = []
        for r_data in reviewers_data:
            result.append(r_data['_account_id'])

        change_number = change_dict['_number']
        review_file = open(review_file_name, 'a+')
        review_file.write("%s:" % change_number)
        review_file.write(str(result))
        review_file.write('\n')
        self.change_reviewers[change_number] = result

    def get_change_reviewers(self, status, start_index, thread_number, end_flag_map):
        """
        One download thread with start index.
        For example, if start_index=100, thread_number=10,
        this thread will download 100-199th, 1100-1199th,
        2100-2199th... changes's reviewers.
        :param status: changes' status, merged or abandoned
        :param end_flag_map: when this thread end, label end flag to 1 in this map.
        :return:
        """
        change_data_number = self.get_change_number(status)
        i = start_index

        name_index =  start_index / num_change_data_per_slice
        review_file_name = global_variable.reviewer_dir_path + self.name+"/" + \
                           status+ "/" + "%s" % name_index

        while i < change_data_number:
            file_path = global_variable.code_review_path + self.name + '/' + \
                        status + '/' + '%s-%s.json' % (i, i + num_change_data_per_slice - 1)
            change_data_slice = utils.parse_json_file(file_path)

            for change_data in change_data_slice:
                change_number = change_data['_number']
                try:
                    touch = self.change_reviewers[change_number]
                except:
                    self.get_reviewers_from_network(change_data, review_file_name)
            i = i + thread_number * num_change_data_per_slice
        end_flag_map[name_index] = 1

    def download_reviewers(self, status, thread_number):
        """
        Download reviewers of changes and save to disk.
        :param status: changes' status, merged or abandoned
        :param thread_number: download reviewers using multithread, number of the threads
        :return: None
        """
        end_flag_map = {}
        t =0
        while t < thread_number:
            end_flag_map[t] = 0
            t += 1

        i = 0
        while i < thread_number * num_change_data_per_slice:
            thread.start_new_thread(self.get_change_reviewers,
                                    (status, i, thread_number,end_flag_map,))
            i = i + num_change_data_per_slice

        while True:
            time.sleep(60)
            t = 0
            tn = 0
            while t < thread_number:
                if end_flag_map[t] == 1:
                    tn += 1
                t += 1

            if tn == thread_number:
                break
            print "%s threads end." % tn
            print "%s-%s : %s" % (self.name, status, len(self.change_reviewers))

        print "%s-%s end" % (self.name, status)
