from features import file_feature
from features import author_feature
from features import code_feature
from features import simple_feature
from features import message_feature
from features import ProjectSetFeaturesMap
from features import feature_utils
from features import exceptions as feature_exception
from baseline_features import baseline_metadata_feature
from baseline_features import baseline_code_feature
from icse_paper_features import pull_request_features as icse_pull_req_feature
from icse_paper_features import project_feature as icse_project_feature
from icse_paper_features import developer_feature as icse_dev_feature
import global_variable
import cPickle
import os

code_feature_path = ''
simple_feature_path = ''
file_feature_path = ''
author_personal_feature_path = ''
author_social_feature_path = ''
commit_message_feature_path = ''
baseline_metadata_feature_path = ''
baseline_code_feature_path = ''
icse_pull_req_feature_path = ''
icse_project_feature_path = ''
icse_dev_feature_path = ''


def initialize_serialize_paths(p_set_name, sub_project_name=None):
    global code_feature_path
    global simple_feature_path
    global file_feature_path
    global author_personal_feature_path
    global author_social_feature_path
    global commit_message_feature_path
    global baseline_metadata_feature_path
    global baseline_code_feature_path
    global icse_pull_req_feature_path
    global icse_project_feature_path
    global icse_dev_feature_path

    if sub_project_name is None:
        serialize_dir = global_variable.serialize_file_path + p_set_name + '/' + 'features_maps/'
    else:
        serialize_dir = global_variable.serialize_file_path + p_set_name + '/' + \
            sub_project_name + '/features_maps/'

    if not os.path.exists(serialize_dir):
        os.mkdir(serialize_dir)
    code_feature_path = serialize_dir + 'code_map'
    simple_feature_path = serialize_dir + 'simple_map'
    file_feature_path = serialize_dir + 'file_map'
    author_personal_feature_path = serialize_dir + 'author_personal_map'
    author_social_feature_path = serialize_dir + 'author_social_map'
    commit_message_feature_path = serialize_dir + 'commit_message_map'
    baseline_metadata_feature_path = serialize_dir + 'baseline_metadata_map'
    baseline_code_feature_path = serialize_dir + 'baseline_code_map'
    icse_pull_req_feature_path = serialize_dir + 'icse_pull_req_map'
    icse_project_feature_path = serialize_dir + 'icse_project_map'
    icse_dev_feature_path = serialize_dir + 'icse_dev_map'


def serialize_file(path, obj):
    file_obj = open(path, 'wb')
    cPickle.dump(obj, file_obj)
    file_obj.close()


def deserialize_file(path):
    file_obj = open(path, 'rb')
    try:
        return_val = cPickle.load(file_obj)
    except:
        return_val = None
    finally:
        file_obj.close()
    return return_val


def extract_single_code_review(p_set_name, sub_project_name, ch, feature_cls_name):
    print '%s feature %s' % (feature_cls_name, ch.change_number)
    fs = None

    if feature_cls_name == 'code':
        fs = code_feature.CodeFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'simple':
        fs = simple_feature.SimpleFeatures(ch)
    elif feature_cls_name == 'file':
        fs = file_feature.FileFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'author_personal':
        fs = author_feature.AuthorPersonalFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'author_social':
        fs = author_feature.AuthorSocialFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'commit_message':
        fs = message_feature.CommitMessageFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'baseline_code':
        fs = baseline_code_feature.BaselineCodeFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'baseline_metadata':
        fs = baseline_metadata_feature.MetadataFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'icse_pull_req':
        fs = icse_pull_req_feature.PullRequestFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'icse_project':
        fs = icse_project_feature.ProjectFeatures(p_set_name, sub_project_name, ch)
    elif feature_cls_name == 'icse_dev':
        fs = icse_dev_feature.DeveloperFeatures(p_set_name, sub_project_name, ch)

    if fs is None:
        return None
    else:
        try:
            fs.extract_features()
            return fs.to_dict()
        except feature_exception.NotConsistentException:
            print '%s not consistent' % ch.change_number
        except IOError:
            print 'IO_ERROR'


def extract_all_code_reviews(p_set_name, sub_project_name, feature_cls_name,
                             start_time=None, end_time=None):
    sorted_change_map = feature_utils.\
        get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    features_map = {}
    i = 1
    num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        i += 1
        if start_time is not None and before_of(ch.created, start_time):
            continue
        if end_time is not None and after_of(ch.created, end_time):
            continue
        fs_dict = extract_single_code_review(p_set_name, sub_project_name, ch, feature_cls_name)
        if fs_dict is not None:
            features_map[ch.change_number] = fs_dict

    if feature_cls_name == 'code':
        my_path = code_feature_path
    elif feature_cls_name == 'simple':
        my_path = simple_feature_path
    elif feature_cls_name == 'file':
        my_path = file_feature_path
    elif feature_cls_name == 'author_personal':
        my_path = author_personal_feature_path
    elif feature_cls_name == 'author_social':
        my_path = author_social_feature_path
    elif feature_cls_name == 'commit_message':
        my_path = commit_message_feature_path
    elif feature_cls_name == 'baseline_code':
        my_path = baseline_code_feature_path
    elif feature_cls_name == 'baseline_metadata':
        my_path = baseline_metadata_feature_path
    elif feature_cls_name == 'icse_pull_req':
        my_path = icse_pull_req_feature_path
    elif feature_cls_name == 'icse_project':
        my_path = icse_project_feature_path
    elif feature_cls_name == 'icse_dev':
        my_path = icse_dev_feature_path
    else:
        my_path = ''
    serialize_file(my_path, features_map)


# def extract_all_code_reviews_partial(p_set_name, feature_cls_name, from_number, to_number):
#     my_path = global_variable.serialize_file_path + p_set_name + '/' + 'temp_maps/'
#     if not os.path.exists(my_path):
#         os.makedirs(my_path)
#     my_path = my_path + feature_cls_name + '_' + str(from_number) + '_' + str(to_number)
#     if os.path.exists(my_path):
#         return
#     sorted_change_map = feature_utils.get_sorted_change_map(p_set_name)
#     features_map = {}
#     i = from_number
#     num = 0
#     while i < to_number:
#         try:
#             ch = sorted_change_map[i]
#         except KeyError:
#             i += 1
#             continue
#         num += 1
#         fs_dict = extract_single_code_review(p_set_name, ch, feature_cls_name)
#         if fs_dict is not None:
#             features_map[ch.change_number] = fs_dict
#         i += 1
#     serialize_file(my_path, features_map)

def project_set_all_features_map(p_set_name, sub_project_name):
    p_set_map = ProjectSetFeaturesMap(p_set_name, sub_project_name)
    # if (not is_baseline) and (not is_icse):
    code_feature_map = deserialize_file(code_feature_path)
    # simple_feature_map = deserialize_file(simple_feature_path)
    # file_feature_map = deserialize_file(file_feature_path)
    # author_personal_feature_map = deserialize_file(author_personal_feature_path)
    # author_social_feature_map = deserialize_file(author_social_feature_path)
    # commit_message_feature_map = deserialize_file(commit_message_feature_path)
    p_set_map.add_features_from_map(code_feature_map)
    # p_set_map.add_features_from_map(simple_feature_map)
    # p_set_map.add_features_from_map(file_feature_map)
    # p_set_map.add_features_from_map(author_personal_feature_map)
    # p_set_map.add_features_from_map(author_social_feature_map)
    # p_set_map.add_features_from_map(commit_message_feature_map)
    # elif is_baseline and (not is_icse):
    baseline_metadata_feature_map = deserialize_file(baseline_metadata_feature_path)
    baseline_code_feature_map = deserialize_file(baseline_code_feature_path)
    p_set_map.add_features_from_map(baseline_metadata_feature_map)
    p_set_map.add_features_from_map(baseline_code_feature_map)
    # elif is_icse and (not is_baseline):
    # icse_pull_req_feature_map = deserialize_file(icse_pull_req_feature_path)
    # icse_project_feature_map = deserialize_file(icse_project_feature_path)
    # icse_dev_feature_map = deserialize_file(icse_dev_feature_path)
    # p_set_map.add_features_from_map(icse_pull_req_feature_map)
    # p_set_map.add_features_from_map(icse_project_feature_map)
    # p_set_map.add_features_from_map(icse_dev_feature_map)
    return p_set_map


def before_of(this_time_str, start_time_str):
    year1 = int(this_time_str.split('-')[0])
    year2 = int(start_time_str.split('-')[0])
    month1 = int(this_time_str.split('-')[1])
    month2 = int(start_time_str.split('-')[1])
    if year1 < year2:
        return True
    elif year1 > year2:
        return False
    else:
        if month1 < month2:
            return True
        else:
            return False


def after_of(this_time_str, end_time_str):
    year1 = int(this_time_str.split('-')[0])
    year2 = int(end_time_str.split('-')[0])
    month1 = int(this_time_str.split('-')[1])
    month2 = int(end_time_str.split('-')[1])
    if year1 > year2:
        return True
    elif year1 < year2:
        return False
    else:
        if month1 <= month2:
            return False
        else:
            return True


def generate_raw_message_arff(p_set_name, sub_project_name,
                              arff_path, start_change_no, change_num,
                              relation, valid_change_numbers):
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    i = start_change_no
    num = 0
    while num < change_num:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        if ch.change_number in valid_change_numbers:
            num += 1
            msg_fs = message_feature.CommitMessageFeatures(p_set_name, sub_project_name, ch)
            msg_fs.msg_to_arff(arff_path, relation)
        i += 1
    return i


def generate_dataset_files(p_set_name,
                           sub_project_name,
                           project_features_map,
                           start_time_str,
                           end_time_str,
                           file_type='arff',
                           is_baseline=False,
                           is_icse = False):
    assert(isinstance(project_features_map, ProjectSetFeaturesMap))
    feature_fields = []
    arff_file_path = ''
    if (not is_baseline) and (not is_icse):
        feature_fields += global_variable.feature_dict['simple_features'] + \
            global_variable.feature_dict['code_features'] + \
            global_variable.feature_dict['file_features'] + \
            global_variable.feature_dict['author_features']['personal'] + \
            global_variable.feature_dict['author_features']['social'] + \
            global_variable.feature_dict['message_features']
        arff_file_path = global_variable.my_arff_file_path
    elif is_baseline and (not is_icse):
        code_feature_fields = []
        for lang in global_variable.language_project_map[p_set_name]:
            try:
                code_feature_fields += global_variable.baseline_features_dict['code_features'][lang]
            except KeyError:
                pass
        feature_fields += global_variable.baseline_features_dict['meta_data_features'] + \
            code_feature_fields
        arff_file_path = global_variable.baseline_arff_file_path
    elif is_icse and (not is_baseline):
        feature_fields += global_variable.icse_feature_dict['pull_request'] + \
            global_variable.icse_feature_dict['project'] + \
            global_variable.icse_feature_dict['developer']
        arff_file_path = global_variable.icse_arff_file_path
    if sub_project_name is None:
        arff_dir = arff_file_path + p_set_name + '/'
    else:
        arff_dir = arff_file_path + p_set_name + '/' + \
            sub_project_name + '/'
    if (not os.path.exists(arff_dir)) and file_type == 'arff':
        os.makedirs(arff_dir)
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        created = ch.created
        if not before_of(created, start_time_str):
            break
        i += 1
    valid_num = 0
    start_change_no = i
    valid_change_numbers = set()
    valid_merge_change_numbers = []
    merged_change_num = 0
    abandoned_change_num = 0
    projects = set()
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
            if before_of(ch.created, start_time_str):
                print ch.created
                raise Exception
        except KeyError:
            i += 1
            continue
        num += 1
        created = ch.created
        if after_of(created, end_time_str):
            break
        if project_features_map.is_valid_change(ch.change_number, feature_fields):
            if not (len(ch.reviewers) == 1 and ch.owner in ch.reviewers):
                valid_num += 1
                valid_change_numbers.add(ch.change_number)
                projects.add(ch.project)
                if ch.status == 'MERGED':
                    merged_change_num += 1
                    valid_merge_change_numbers.append(ch.change_number)
                else:
                    abandoned_change_num += 1
        i += 1

    change_num = valid_num
    each_component_num = change_num / 11
    j = 0
    print change_num
    print merged_change_num
    print abandoned_change_num
    print float(abandoned_change_num) / float(change_num)
    print len(projects)
    while j < 10:
        print j
        this_arff_dir = arff_dir + str(j) + '/'
        if not os.path.exists(this_arff_dir):
            os.mkdir(this_arff_dir)
        this_train_path = this_arff_dir + 'train.arff'
        this_test_path = this_arff_dir + 'test.arff'
        this_train_msg_path = this_arff_dir + 'raw_msg_train.arff'
        this_test_msg_path = this_arff_dir + 'raw_msg_test.arff'
        train_num = each_component_num * (j+1)
        if j < 9:
            test_num = each_component_num
        else:
            test_num = valid_num - train_num
        if os.path.exists(this_train_msg_path):
            os.remove(this_train_msg_path)
        if os.path.exists(this_test_msg_path):
            os.remove(this_test_msg_path)

        next_start = project_features_map.partial_to_arff(this_train_path, start_change_no,
                                                          train_num, 'train', valid_change_numbers,
                                                          is_baseline=is_baseline,
                                                          is_icse=is_icse)
        project_features_map.partial_to_arff(this_test_path, next_start,
                                             test_num, 'test', valid_change_numbers,
                                             is_baseline=is_baseline,
                                             is_icse=is_icse)
        start_change_no = next_start
        # if (not is_baseline) and (not is_icse):
        #     next_msg_start = generate_raw_message_arff(p_set_name, sub_project_name,
        #                                                this_train_msg_path, start_change_no,
        #                                                train_num, 'msg_train', valid_change_numbers)
        #     generate_raw_message_arff(p_set_name, sub_project_name, this_test_msg_path,
        #                               next_msg_start, test_num, 'msg_test', valid_change_numbers)
        #     assert(next_msg_start == next_start)
        j += 1


def get_valid_change_numbers(p_set_name, sub_project_name, project_features_map,
                             start_time_str='1900-1', end_time_str='3000-1', status=None):
    feature_fields = []
    feature_fields += global_variable.feature_dict['code_features']
        # global_variable.feature_dict['simple_features'] + \
        # global_variable.feature_dict['file_features'] + \
        # global_variable.feature_dict['author_features']['personal'] + \
        # global_variable.feature_dict['author_features']['social'] + \
        # global_variable.feature_dict['message_features']

    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        created = ch.created
        if not before_of(created, start_time_str):
            break
        i += 1
    valid_num = 0
    start_change_no = i
    valid_change_numbers = set()
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
            if before_of(ch.created, start_time_str):
                print ch.created
                raise Exception
        except KeyError:
            i += 1
            continue
        num += 1
        if status is not None and ch.status != status:
            i += 1
            continue
        created = ch.created
        if after_of(created, end_time_str):
            break
        if project_features_map.is_valid_change(ch.change_number, feature_fields):
            if not (len(ch.reviewers) == 1 and ch.owner in ch.reviewers):
                valid_num += 1
                valid_change_numbers.add(ch.change_number)
        i += 1
    print valid_num
    return start_change_no, valid_change_numbers


def extract_features(p_set_name, sub_project_name,
                     feature_mask='xxxxxxbbiii',
                     start_time_str='1900-1', end_time_str='3000-1'):
    initialize_serialize_paths(p_set_name, sub_project_name)
    if feature_mask[0] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'code')
    if feature_mask[1] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'simple')
    if feature_mask[2] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'file')
    if feature_mask[3] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'author_personal')
    if feature_mask[4] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'author_social')
    if feature_mask[5] == 'x':
        extract_all_code_reviews(p_set_name, sub_project_name, 'commit_message')
    if feature_mask[6] == 'b':
        extract_all_code_reviews(p_set_name, sub_project_name, 'baseline_code')
    if feature_mask[7] == 'b':
        extract_all_code_reviews(p_set_name, sub_project_name, 'baseline_metadata')
    if feature_mask[8] == 'i':
        extract_all_code_reviews(p_set_name, sub_project_name, 'icse_pull_req')
    if feature_mask[9] == 'i':
        extract_all_code_reviews(p_set_name, sub_project_name, 'icse_project')
    if feature_mask[10] == 'i':
        extract_all_code_reviews(p_set_name, sub_project_name, 'icse_dev')
    project_features_map = project_set_all_features_map(p_set_name, sub_project_name)
    print 'features_map got!'
    # generate_dataset_files(p_set_name, sub_project_name, project_features_map,
    #                        start_time_str, end_time_str, 'arff',
    #                        is_baseline=False, is_icse=False)
    # generate_dataset_files(p_set_name, sub_project_name, project_features_map,
    #                        start_time_str, end_time_str, 'arff',
    #                        is_baseline=False, is_icse=True)
    generate_dataset_files(p_set_name, sub_project_name, project_features_map,
                           start_time_str, end_time_str, 'arff',
                           is_baseline=False, is_icse=False)


def generate_overall_dataset(p_set_name, sub_project_name, start_time_str='1900-1', end_time_str='3000-1', is_csv=True, status=None):
    initialize_serialize_paths(p_set_name, sub_project_name)

    features_map = project_set_all_features_map(p_set_name, sub_project_name)

    fields = []
    # fields += global_variable.feature_dict['simple_features'] + \
    #     global_variable.feature_dict['code_features'] + \
    #     global_variable.feature_dict['file_features'] + \
    #     global_variable.feature_dict['author_features']['personal'] + \
    #     global_variable.feature_dict['author_features']['social'] + \
    #     global_variable.feature_dict['message_features']

    # fields += global_variable.icse_feature_dict['pull_request'] + \
    #                   global_variable.icse_feature_dict['project'] + \
    #                   global_variable.icse_feature_dict['developer']
    code_feature_fields = []
    for lang in global_variable.language_project_map[p_set_name]:
        try:
            code_feature_fields += global_variable.baseline_features_dict['code_features'][lang]
        except KeyError:
            pass
    fields += global_variable.baseline_features_dict['meta_data_features'] + \
                      code_feature_fields

    start_no, valid_numbers = get_valid_change_numbers(p_set_name, sub_project_name,
                                                       features_map, start_time_str, end_time_str, status=status)
    if is_csv:
        csv_dir = global_variable.csv_file_path
        if not os.path.exists(csv_dir):
            os.makedirs(csv_dir)
        overall_csv_path = csv_dir + 'overall.csv'
        if status is not None:
            overall_csv_path = csv_dir + status+ '_overall.csv'

        features_map.to_csv(overall_csv_path, start_no, valid_numbers, fields)
    else:
        arff_dir = global_variable.arff_file_path
        if not os.path.exists(arff_dir):
            os.makedirs(arff_dir)
        arff_path = arff_dir + p_set_name + '.arff'
        features_map.to_arff(arff_path, start_no, valid_numbers, fields)

    print '%s end' % p_set_name


if __name__ == '__main__':
    # for p_set_name in ['libreoffice']:
    #     for sub_project_name in global_variable.candidate_sub_project[p_set_name]:
    #         print sub_project_name
    #         extract_features(p_set_name, sub_project_name, '00000000', is_baseline=False)
    # extract_features('eclipse', None, '00000000000')
    # extract_features('libreoffice', None, '00000000000')
    # extract_features('openstack', None, '00000000000', '2015-1', '2015-12')
    # initialize_serialize_paths('openstack', None)
    # project_feature_map = project_set_all_features_map('openstack', None)
    # get_valid_change_numbers('openstack', None, project_feature_map,
    #                          '2015-1', '2015-12')
    # generate_overall_dataset('eclipse', None, status='ABANDONED')
    # generate_overall_dataset('libreoffice', None, status='MERGED')
    # generate_overall_dataset('openstack', None, '2015-1', '2015-12', status='MERGED')
    # generate_overall_dataset('eclipse', None, is_csv=False)
    # generate_overall_dataset('libreoffice', None, is_csv=False)
    generate_overall_dataset('openstack', None, start_time_str='2015-1', end_time_str='2015-12', is_csv=False)
