class File:
    def __init__(self, file_path, insertions, deletions, is_binary=False, status=None):
        self.file_path = file_path
        self.is_binary = is_binary
        self.insertions = insertions
        self.deletions = deletions
        self.status = status


class Fetch:
    def __init__(self, url, ref):
        self.url = url
        self.ref = ref


class Revision:
    def __init__(self, commit_id, revision_dict):
        self.commit_id = commit_id
        self.message = revision_dict['commit']['message']
        self.fetch = None
        self.files = None
        self.set_fetch(revision_dict['fetch'])
        self.set_file(revision_dict['files'])

    def set_fetch(self, fetch_dict):
        try:
            url = fetch_dict['git']['url']
            ref = fetch_dict['git']['ref']
        except KeyError:
            url = fetch_dict['anonymous http']['url']
            ref = fetch_dict['anonymous http']['ref']

        self.fetch = Fetch(url, ref)

    def set_file(self, files_dict):
        self.files = []
        assert(isinstance(files_dict, dict))
        for file_path in files_dict.keys():
            file_insertions = 0
            file_deletions = 0
            is_binary = False
            status = None
            assert(isinstance(files_dict[file_path], dict))
            try:
                file_insertions = files_dict[file_path]['lines_inserted']
            except KeyError:
                pass
            try:
                file_deletions = files_dict[file_path]['lines_deleted']
            except KeyError:
                pass
            try:
                is_binary = files_dict[file_path]['binary']
            except KeyError:
                pass
            try:
                status = files_dict[file_path]['status']
            except KeyError:
                pass

            f = File(file_path, file_insertions, file_deletions, is_binary=is_binary, status=status)
            self.files.append(f)
