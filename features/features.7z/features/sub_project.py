
import os

import multiprocessing

import global_variable
import project_set


git_path = global_variable.git_path
mp_projects = global_variable.multi_process_download_projects


def store_to_file(git_show_sub_project_dir, ref):
    file_path = git_show_sub_project_dir + ref.split('/')[-2] + '.txt'
    if os.path.exists(file_path):
        return
    git_show_str = os.popen('git show %s' % ref).read()
    if git_show_str is None:
        print git_show_sub_project_dir
    file_obj = open(file_path, 'w+')
    file_obj.write(git_show_str)
    file_obj.close()


class SubProject:
    def __init__(self, project_set_instance, sub_project_name, git_url=None):
        assert(isinstance(project_set_instance, project_set.ProjectSet))
        self.name = sub_project_name
        self.project_set_name = project_set_instance.name
        self.git_url = git_url
        self.repo_path = git_path + project_set_instance.name + '/' + sub_project_name + '/'
        self.git_path = git_path + project_set_instance.name + '/' + sub_project_name + '/.git/'
        self.refs = []
        self.end_download = False

    def make_project_dirs(self):
        """
        Make .git directories for all the projects.
        """
        # if (self.project_set_name in mp_projects.keys()) and \
        #                 self.name in mp_projects[self.project_set_name]:
        #     i = 0
        #     while i < 20:
        #         path = self.repo_path + self.name.split('/')[-1] + str(i) + '/.git'
        #         if not os.path.exists(path):
        #             os.makedirs(path)
        #             import git
        #             git.Repo.init(path, bare=True)
        #         i += 1
        #
        # elif not os.path.exists(self.git_path):
        #     import git
        #     os.makedirs(self.git_path)
        #     git.Repo.init(self.git_path, bare=True)
        pass

    def multi_process_fetch_changes(self):
        """
        Some projects need download with multiprocess.
        Default multi_process number is 20. First split
        refs into 20 partitions and download them into
        20 different paths.
        """
        def single_dir_fetch_changes(dir_number):
            path = self.repo_path + self.name.split('/')[-1] + str(dir_number) + '/'
            os.chdir(path)
            print path
            str_branches = os.popen('git branch --all').read()
            ref_length = self.refs.__len__()
            i = 0
            while i < ref_length:
                if i % 20 == dir_number:
                    ref = self.refs[i]
                    try:
                        if ref in str_branches:
                            i += 1
                            continue
                        os.system('git fetch %s %s' % (self.git_url, ref))
                        os.system('git branch %s FETCH_HEAD' % ref)
                    except:
                        print 'has exception'
                        pass
                i += 1

            print "%s end" % path

        if self.project_set_name in mp_projects.keys() and \
                        self.name in mp_projects[self.project_set_name]:
            i = 0
            processes = []
            while i < 20:
                p1 = multiprocessing.Process(target=single_dir_fetch_changes, args=(i,))
                p1.start()
                processes.append(p1)
                i += 1

            i = 0
            while i < 20:
                processes[i].join()
                i += 1

    def fetch_all_change(self):

        if self.project_set_name in mp_projects.keys() and \
                        self.name in mp_projects[self.project_set_name]:
            return
        else:
            os.chdir(self.repo_path)
            str_branches = os.popen('git branch --all').read()
            # for ref in self.refs:
            #     try:
            #         if ref in str_branches:
            #             continue
            #         os.system('git fetch %s %s' % (self.git_url, ref))
            #         os.system('git branch %s FETCH_HEAD' % ref)
            #     except:
            #         print "has exception"
            #         pass
            git_show_sub_project_dir = global_variable.git_show_path + \
                                   self.project_set_name + '/' + self.name+'/'
            for ref in self.refs:
                file_path = git_show_sub_project_dir + ref.split('/')[-2] + '.txt'
                if os.path.exists(file_path):
                    continue
                try:
                    if ref in str_branches:
                        continue
                    os.system('git fetch %s %s' % (self.git_url, ref))
                    os.system('git branch %s FETCH_HEAD' % ref)
                except:
                    print "has exception"
                    pass



            print "%s end" % (self.name)

    def get_downloaded_changes_number(self):
        git_show_sub_project_dir = global_variable.git_show_path + \
                                   self.project_set_name + '/' + self.name + '/'
        change_num = 0
        for ref in self.refs:
            file_path = git_show_sub_project_dir + ref.split('/')[-2] + '.txt'
            if os.path.exists(file_path):
                change_num += 1
        # if (self.project_set_name in mp_projects.keys()) and \
        #                 self.name in mp_projects[self.project_set_name]:
        #     i = 0
        #     while i < 20:
        #         change_num += self.mp_get_downloaded_changes_number(i)
        #         i += 1
        # else:
        #     os.chdir(self.repo_path)
        #     str = ''
        #     try:
        #         str = os.popen('git branch --all').read()
        #     except:
        #         return 0
        #
        #     for ref in self.refs:
        #         if ref in str:
        #             change_num += 1

        if change_num == len(self.refs):
            self.end_download = True

        return change_num

    def mp_get_downloaded_changes_number(self, dir_number):
            path = self.repo_path + self.name.split('/')[-1] + str(dir_number) + '/'
            os.chdir(path)
            str_branches = os.popen('git branch --all').read()
            i = 0
            number = 0
            ref_length = self.refs.__len__()
            while i < ref_length:
                if i % 20 == dir_number:
                    ref = self.refs[i]
                    try:
                        if ref in str_branches:
                            i += 1
                            number += 1
                            continue
                    except:
                        print 'has exception'
                        pass
                i += 1
            return number

    def store_git_show_files(self):
        git_show_sub_project_dir = global_variable.git_show_path + \
                                   self.project_set_name + '/' + self.name+'/'
        if not os.path.exists(git_show_sub_project_dir):
            os.makedirs(git_show_sub_project_dir)

        if self.project_set_name in mp_projects.keys() and \
                        self.name in mp_projects[self.project_set_name]:
            i = 0
            while i < 20:
                path = self.repo_path + self.name.split('/')[-1] + str(i) + '/'
                print path
                os.chdir(path)
                ref_len = len(self.refs)
                j = 0
                if self.end_download:
                    while j < ref_len:
                        if j % 20 == i:
                            store_to_file(git_show_sub_project_dir, self.refs[j])
                        j += 1
                else:
                    str_branches = os.popen('git branch --all').read()
                    while j < ref_len:
                        if j % 20 == i:
                            if self.refs[j] in str_branches:
                                store_to_file(git_show_sub_project_dir, self.refs[j])
                        j += 1
                i += 1

        else:
            os.chdir(self.repo_path)
            if self.end_download:
                for ref in self.refs:
                    store_to_file(git_show_sub_project_dir, ref)
            else:
                str_branches = os.popen('git branch --all').read()
                for ref in self.refs:
                    if ref in str_branches:
                        store_to_file(git_show_sub_project_dir, ref)

