import project_set
import sub_project

if __name__ == "__main__":
    for p_set in ['eclipse']:
        sub_project_map = project_set.deserialize_sub_projects_map(p_set)
        for sub_p_name in sub_project_map.keys():
            sub_p = sub_project_map[sub_p_name]
            assert(isinstance(sub_p, sub_project.SubProject))
            sub_p.store_git_show_files()
            print "%s %s end" % (p_set, sub_p_name)
