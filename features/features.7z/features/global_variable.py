# file paths
root_directory = '/Volumes/Untitled/my papers/merged change prediction/code/'
disk_directory = root_directory + 'dataset/'
code_review_path = disk_directory + 'download_repositories/'
my_code_project_dir = root_directory + 'miningcodereviews/'
log_path = my_code_project_dir + 'log/'
git_path = disk_directory + 'repos/'
reviewer_dir_path = my_code_project_dir + 'reviewers/'
git_show_path = disk_directory + 'git-shows/'
serialize_file_path = my_code_project_dir + 'binary_file/'

csv_file_path = root_directory + 'dataset/csv_file_openstack/'
arff_file_path = root_directory + 'dataset/arff_files_baseline/'

my_arff_file_path = root_directory + 'dataset/arff_file_new/'
icse_arff_file_path = root_directory + 'dataset/arff_file_icse/'
baseline_arff_file_path = root_directory + 'dataset/arff_file_baseline/'

# settings when download code review json format metadata
project_sets = ['eclipse', 'libreoffice', 'openstack']
status = ['merged', 'abandoned']
num_change_data_per_slice = 100

# RESTful urls
change_urls = {}
change_urls['eclipse'] = 'https://git.eclipse.org/r/changes/'
change_urls['openstack'] = 'https://review.openstack.org/changes/'
change_urls['gerrit'] = 'https://review.gerrithub.io/changes/'
change_urls['libreoffice'] = 'https://gerrit.libreoffice.org/changes/'

# setting projects which will be downloaded using multiprocess
multi_process_download_projects={
}

# candidate sub projects which will be mined.
candidate_sub_project = {
    'eclipse': ['papyrus',
                'egit'],
    'libreoffice': ['core'],
    'openstack': ['openstack/nova',
                  'openstack/horizon'],
}

feature_dict = {
    'simple_features': [
                        'status',
                        'lines_added_num', 'lines_deleted_num', 'file_num', 'modify_entropy',
                        'language_num', 'directory_num', 'subsystem_num', 'file_type_num',
                        'file_added_num', 'file_deleted_num'
    ],
    'file_features': [
        'changes_files_modified', 'file_developer_num'
    ],
    'author_features': {
        'personal': [
            'author_code_review_num',
            'author_merged_ratio',
            'author_recent_code_review_num',
            'author_recent_merged_ratio',
            'author_subsystem_code_review_num',
            'author_subsystem_merged_ratio',
            'author_reviewed_num'
        ],
        'social': [
            'social_degree', 'social_closeness', 'social_betweenness',
            'social_eigenvector', 'social_clustering', 'social_k_coreness'
        ]
    },
    'code_features': [
        'segs_added_num', 'segs_deleted_num', 'segs_updated_num',
    ],
    'message_features': [
        'msg_length', 'has_bug', 'has_feature',
        'has_improve', 'has_document', 'has_refactor'
    ],
}

baseline_features_dict = {
    'meta_data_features': ['status',
                           # 'owner',
                           'patch_length', 'baseline_file_num',
                           'baseline_lines_added_num', 'baseline_lines_deleted_num'],
    'code_features': {
        'common': ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
                   'continue_num', 'return_num', 'try_num'],
        # 'java': ['boolean_num', 'break_num', 'catch_num', 'char_num', 'class_num', 'continue_num',
        #          'do_num', 'double_num', 'extends_num', 'final_num', 'finally_num', 'float_num',
        #          'for_num', 'if_num', 'else_num', 'implements_num', 'interface_num', 'new_num',
        #          'private_num', 'protected_num', 'public_num', 'return_num', 'static_num', 'super_num',
        #          'synchronized_num', 'this_num', 'throw_num', 'try_num', 'while_num', 'null_num',
        #          'get_num', 'set_num', '{_num', '}_num'],
        'java': ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
                   'continue_num', 'return_num', 'try_num'],
        # 'cpp': [
            # 'bool_num', 'break_num', 'catch_num', 'char_num', 'class_num', 'continue_num',
            #     'do_num', 'double_num', 'goto_num', 'final_num', 'struct_num', 'float_num',
            #     'for_num', 'if_num', 'else_num', 'virtual_num', 'template_num', 'new_num',
            #     'private_num', 'protected_num', 'public_num', 'return_num', 'static_num',
            #     'delete_num', 'this_num', 'throw_num', 'try_num', 'while_num', 'NULL_num',
            #     'typedef_num', 'inline_num', '{_num', '}_num'
        # ],
        # 'py': [
            # 'and_num', 'as_num', 'assert_num', 'break_num', 'class_num', 'continue_num',
            #    'def_num', 'del_num', 'elif_num', 'else_num', 'except_num', 'finally_num',
            #    'for_num', 'from_num', 'global_num', 'if_num', 'in_num', 'is_num', 'not_num',
            #    'None_num', 'or_num', 'pass_num', 'raise_num', 'return_num', 'try_num',
            #    'while_num', 'with_num', 'yield_num', ':_num'
        # ]
        # 'java': ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
        #            'continue_num', 'return_num', 'try_num'],
        'cpp': ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
                'continue_num', 'return_num', 'try_num'],
        'py': ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
                'continue_num', 'return_num', 'try_num']
    },
}


icse_feature_dict = {
    'pull_request':[
         'status', 'src_churn', 'test_churn', 'sloc',
         'files_changed', 'has_conflict', 'has_forward_link'
    ],
    'project': [
        'commits_files_touched', 'test_lines_per_kloc'
    ],
    'developer': [
        'prev_pullreqs', 'requester_succ_rate'
    ]
}

# main language settings for three community.
language_project_map = {
    'eclipse': ['java'],
    'libreoffice': ['cpp', 'c', 'cxx', 'hpp', 'hxx', 'h'],
    'openstack': ['py']
}


def add_args(all_revisions=True, all_files=True,
             all_commits=True, messages=True,
             detailed_accounts=True, num_one_step=100):
    for key in change_urls.keys():
        url = change_urls[key]
        url += '?'
        if all_revisions:
            url += 'o=ALL_REVISIONS&'
        if all_files:
            url += 'o=ALL_FILES&'
        if all_commits:
            url += 'o=ALL_COMMITS&'
        if messages:
            url += 'o=MESSAGES&'
        if detailed_accounts:
            url += 'o=DETAILED_ACCOUNTS&'

        url += 'n=%s&' % num_one_step
        change_urls[key] = url
