from features import Features
from features import feature_utils
import global_variable
import code_review


def add_headers_to_arff_path(arff_path, p_set_name, sub_project_name):
    attributes = {}
    numeric_attr = 'numeric'
    feature_fields = global_variable.icse_feature_dict['developer']
    for key in feature_fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in feature_fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class DeveloperFeatures(Features):
    """
    'prev_pullreqs': number of pull requests submitted by a
                    specific developer prior to the examined
                    pull request.
    'requester_succ_rate': rate of the developer's pull requests that
                           have been merged up to the creation of the
                           examined pull request.
    """
    @staticmethod
    def get_feature_fields():
        feature_fields = [] + global_variable.icse_feature_dict['developer']
        return feature_fields

    def __init__(self, project_set_name, sub_project_name, simple_code_review):
        assert (isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(DeveloperFeatures, self).__init__(change_number)
        self.feature_fields = self.get_feature_fields()
        self.sorted_change_map = feature_utils.get_sorted_change_map(project_set_name,
                                                                     sub_project_name)
        self.status = simple_code_review.status
        self.owner = simple_code_review.owner
        self.change_map = feature_utils. \
            get_people_change_map(project_set_name, sub_project_name)[self.owner]
        self.created = simple_code_review.created
        self.project = simple_code_review.project

    def extract_features(self):
        self['prev_pullreqs'] = 0
        self['requester_succ_rate'] = 0
        idx = 0
        merged_idx = 0
        change_map_len = len(self.change_map)
        num_processed = 0
        while num_processed < change_map_len:
            change_number = self.change_map[num_processed].change_number
            temp_change = self.sorted_change_map[change_number]
            num_processed += 1
            assert (isinstance(temp_change, code_review.SimpleCodeReview))
            temp_status = temp_change.status
            if change_number == self.change_number:
                break
            else:
                delta_create_day = feature_utils.delta_days(self.created, temp_change.created)
                if delta_create_day < 0:
                    continue
                idx += 1
                if temp_status == 'MERGED':
                    merged_idx += 1

        self['prev_pullreqs'] = idx
        if idx != 0:
            self['requester_succ_rate'] = float(merged_idx) / float(idx)
        else:
            self['requester_succ_rate'] = 0
