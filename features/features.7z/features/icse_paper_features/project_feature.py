from features import Features
from features import feature_utils
import global_variable
import code_review

project_info_map = {}


def get_project_info(p_set_name, sub_project_name):
    global project_info_map
    try:
        project_info_map[p_set_name]
    except KeyError:
        project_info_map[p_set_name] = {}

    try:
        project_info_map[p_set_name][sub_project_name]
    except KeyError:
        project_info_map[p_set_name][sub_project_name] = {}
        project_info_map[p_set_name][sub_project_name]['total_lines'] = 0
        project_info_map[p_set_name][sub_project_name]['test_lines'] = 0
    return project_info_map[p_set_name][sub_project_name]


def add_headers_to_arff_path(arff_path, p_set_name, sub_project_name):
    attributes = {}
    numeric_attr = 'numeric'
    feature_fields = global_variable.icse_feature_dict['project']
    for key in feature_fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in feature_fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class ProjectFeatures(Features):
    """
    'commits_files_touched': Number of total commits on files touched by
                            the pull request 3 months before the pull
                            request creation time.
    'test_lines_per_kloc': A proxy for the project's test coverage.
    """
    @staticmethod
    def get_feature_fields():
        feature_fields = [] + global_variable.icse_feature_dict['project']
        return feature_fields

    def __init__(self, project_set_name, sub_project_name, simple_code_review):
        assert (isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(ProjectFeatures, self).__init__(change_number)
        self.feature_fields = self.get_feature_fields()
        self.sorted_change_map = feature_utils.get_sorted_change_map(project_set_name,
                                                                     sub_project_name)
        self.created = simple_code_review.created
        self.files = simple_code_review.files
        self.project = simple_code_review.project
        self.status = simple_code_review.status
        self.project_info_map = get_project_info(project_set_name, self.project)

    def compute_commits_files_touched(self):
        self['commits_files_touched'] = 0
        i = self.change_number - 1
        file_paths = set()
        for f in self.files:
            file_paths.add(f.file_path)
        while i > 0:
            try:
                ch = self.sorted_change_map[i]
            except KeyError:
                i -= 1
                continue
            delta_days = feature_utils.delta_days(self.created, ch.created)
            if delta_days > 90:
                break
            if ch.project != self.project or delta_days <= 0:
                i -= 1
                continue
            for f in ch.files:
                if f.file_path in file_paths:
                    self['commits_files_touched'] += 1
                    break
            i -= 1

    def compute_test_lines_per_kloc(self):
        test_lines = self.project_info_map['test_lines']
        total_lines = self.project_info_map['total_lines']

        if total_lines != 0:
            self['test_lines_per_kloc'] = float(test_lines) * 1000 / float(total_lines)
        else:
            self['test_lines_per_kloc'] = 0
        if self['test_lines_per_kloc'] < 0:
            self['test_lines_per_kloc'] = 0
        if self.status == 'MERGED':
            for f in self.files:
                self.project_info_map['total_lines'] += f.insertions + f.deletions
                if 'test' in f.file_path or 'Test' in f.file_path:
                    self.project_info_map['test_lines'] += f.insertions + f.deletions

    def extract_features(self):
        self.compute_commits_files_touched()
        self.compute_test_lines_per_kloc()
