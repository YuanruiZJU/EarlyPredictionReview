from features import feature_utils
from icse_paper_features import developer_feature

sorted_change_map = feature_utils.get_sorted_change_map('eclipse')


def extract_features():
    len_sorted = len(sorted_change_map)
    i = 1
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        fs = developer_feature.DeveloperFeatures('eclipse', None, ch)
        fs.extract_features()
        fs.print_features()
        i += 1


extract_features()