from features import Features
from features import feature_utils
import global_variable
import code_review
import nltk

change_urls = {
    'eclipse': 'https://git.eclipse.org/r/',
    'libreoffice': 'https://gerrit.libreoffice.org/',
    'openstack': 'https://review.openstack.org/'
}


def add_headers_to_arff_path(arff_path, p_set_name, sub_project_name):
    attributes = {}
    numeric_attr = 'numeric'
    feature_fields = global_variable.icse_feature_dict['pull_request']
    for key in feature_fields:
        attributes[key] = numeric_attr

    attributes['status'] = '{ABANDONED,MERGED}'
    attributes['has_conflict'] = '{True,False}'
    attributes['has_forward_link'] = '{True,False}'

    f_obj = open(arff_path, 'a+')
    for key in feature_fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class PullRequestFeatures(Features):
    @staticmethod
    def get_feature_fields():
        feature_fields = [] + global_variable.icse_feature_dict['pull_request']
        return feature_fields

    def __init__(self, project_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(PullRequestFeatures, self).__init__(change_number)
        self.files = simple_code_review.files
        message_map = feature_utils.get_message_map(project_set_name, sub_project_name)
        self.msg = message_map[change_number]
        self.p_set_name = project_set_name
        self.feature_fields = self.get_feature_fields()
        self.status = simple_code_review.status

    def extract_features(self):
        s = nltk.stem.SnowballStemmer('english')
        msg_words = nltk.word_tokenize(self.msg)
        self['status'] = self.status
        self['src_churn'] = 0
        self['test_churn'] = 0
        self['files_changed'] = 0
        self['sloc'] = 0
        self['has_conflict'] = False
        self['has_forward_link'] = False

        for f in self.files:
            if f.insertions + f.deletions == 0:
                continue
            self['src_churn'] += f.insertions + f.deletions
            self['sloc'] += f.insertions
            self['files_changed'] += 1
            if 'test' in f.file_path or 'Test' in f.file_path:
                self['test_churn'] += f.insertions + f.deletions

        for word in msg_words:
            if s.stem(word) == 'conflict':
                self['has_conflict'] = True

        if change_urls[self.p_set_name] in self.msg:
            self['has_forward_link'] = True
