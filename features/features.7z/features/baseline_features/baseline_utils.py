from features import feature_utils
import re


def get_keywords_number(lines, start_line, end_line, feature_fields):
    i = start_line
    keywords_number = {}
    keywords = set()
    patterns = {}
    for field in feature_fields:
        keyword = field[:-4]
        keywords.add(keyword)
        keywords_number[field] = 0
    for word in keywords:
        if word not in ['{', '}', ':']:
            patterns[word] = re.compile(r'\b%s\b' % word)
        else:
            patterns[word] = re.compile(word)
    while i < end_line:
        this_line = lines[i]
        try:
            if this_line[0] == '+' or this_line[0] == '-':
                for word in keywords:
                    keywords_number[word + '_num'] += len(patterns[word].findall(this_line))
        except IndexError:
            i += 1
            continue
        i += 1
    return keywords_number


def get_all_owners_str(p_set_name, sub_project_name):
    owners = set()
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        owners.add(ch.owner)
        i += 1
    owners_str = '{'
    for owner in owners:
        owners_str += str(owner)
        owners_str += ','
    owners_str = owners_str[:-1] + '}'
    return owners_str
