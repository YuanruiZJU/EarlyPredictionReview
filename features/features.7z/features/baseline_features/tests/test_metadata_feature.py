from features import feature_utils
from baseline_features import baseline_metadata_feature

p_set_name = 'eclipse'
sub_project_name = 'jgit'


def extract_features():
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name,sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        baseline_meta_fs = baseline_metadata_feature.MetadataFeatures(p_set_name,sub_project_name,ch)
        baseline_meta_fs.extract_features()
        baseline_meta_fs.print_features()
        i += 1

extract_features()
