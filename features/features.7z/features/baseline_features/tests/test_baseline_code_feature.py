from features import feature_utils
from baseline_features import baseline_code_feature
from features import exceptions

p_set_name = 'eclipse'
sub_project_name = 'papyrus'
sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)


def extract_features():
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    code_feature_num = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        try:
            baseline_code_fs = baseline_code_feature.BaselineCodeFeatures(p_set_name, sub_project_name, ch)
            baseline_code_fs.extract_features()
            code_feature_num += 1
            baseline_code_fs.print_features()
        except exceptions.NotConsistentException:
            pass
        except Exception:
            pass
        i += 1
    print code_feature_num

extract_features()