from features import Features
from baseline_features import baseline_utils
import code_review
import global_variable


def add_headers_to_arff_path(arff_path, p_set_name, sub_project_name):
    attributes = {}
    numeric_attr = 'numeric'
    feature_fields = global_variable.baseline_features_dict['meta_data_features']
    for key in feature_fields:
        attributes[key] = numeric_attr

    attributes['owner'] = baseline_utils.get_all_owners_str(p_set_name, sub_project_name)
    attributes['status'] = '{ABANDONED,MERGED}'

    f_obj = open(arff_path, 'a+')
    for key in feature_fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class MetadataFeatures(Features):
    @staticmethod
    def get_feature_fields():
        feature_fields = []
        feature_fields += global_variable.baseline_features_dict['meta_data_features']
        return feature_fields

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(MetadataFeatures, self).__init__(change_number)
        self.status = simple_code_review.status
        self.feature_fields = self.get_feature_fields()
        self.simple_code_review = simple_code_review
        self.git_show_path = global_variable.git_show_path + p_set_name + '/' + \
            simple_code_review.project + '/' + str(self.change_number) + '.txt'

    def extract_features(self):
        file_obj = open(self.git_show_path, 'r')
        git_show_str = file_obj.read()
        file_obj.close()

        self['status'] = self.status
        self['owner'] = self.simple_code_review.owner
        self['patch_length'] = len(git_show_str)
        self['baseline_lines_added_num'] = 0
        self['baseline_lines_deleted_num'] = 0
        self['baseline_file_num'] = len(self.simple_code_review.files)
        for f in self.simple_code_review.files:
            self['baseline_lines_added_num'] += f.insertions
            self['baseline_lines_deleted_num'] += f.deletions
