from features import Features
from features import feature_utils
from baseline_features import baseline_utils
import code_review
import global_variable
import os


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    code_feature_fields = []
    for lang in global_variable.language_project_map[p_set_name]:
        try:
            code_feature_fields += global_variable.baseline_features_dict['code_features'][lang]
        except KeyError:
            pass
    fields = code_feature_fields
    for key in fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        original_key = key
        if key == '{_num':
            key = 'left_bracket_num'
        elif key == '}_num':
            key = 'right_bracket_num'
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[original_key])
        f_obj.write('\n')
    f_obj.close()


class BaselineCodeFeatures(Features):

    def get_code_feature_field(self):
        feature_fields = []
        for language in self.languages:
            try:
                feature_fields += global_variable.baseline_features_dict['code_features'][language]
            except KeyError:
                pass
        return feature_fields

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(BaselineCodeFeatures, self).__init__(change_number)
        self.languages = global_variable.language_project_map[p_set_name]
        self.feature_fields = self.get_code_feature_field()
        self.common_feature_fields = [] + global_variable.baseline_features_dict['code_features']['common']
        self.status = simple_code_review.status
        self.files = simple_code_review.files
        self.git_show_path = global_variable.git_show_path + p_set_name + '/' + \
            simple_code_review.project + '/' + str(self.change_number) + '.txt'

    def extract_features(self):
        file_obj = open(self.git_show_path, 'r')
        git_show_file = file_obj.read()
        file_obj.close()
        lines = git_show_file.split('\n')

        for field in self.feature_fields:
            self[field] = 0
        file_diff_map = feature_utils.parse_git_show_file(lines, self.files)
        for f in self.files:
            if f.insertions + f.deletions == 0:
                continue
            diff_map = file_diff_map[f.file_path]
            start_line = diff_map['start_line']
            end_line = diff_map['end_line']
            seg_maps = feature_utils.segments_maps(lines, start_line, end_line)
            for seg in seg_maps:
                seg_start_line = seg['start_line']
                seg_end_line = seg['end_line']
                if os.path.basename(f.file_path).split('.')[-1] in self.languages:
                    code_features_map = baseline_utils.get_keywords_number(lines,
                                                                           seg_start_line,
                                                                           seg_end_line,
                                                                           self.feature_fields)
                else:
                    code_features_map = baseline_utils.get_keywords_number(lines,
                                                                           seg_start_line,
                                                                           seg_end_line,
                                                                           self.common_feature_fields)
                for field in code_features_map.keys():
                    self[field] += code_features_map[field]
