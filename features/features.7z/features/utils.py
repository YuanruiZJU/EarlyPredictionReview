import cPickle
import simplejson
import os


def serialize_file(file_path, obj):
    dirs = directory_of(file_path)
    if not os.path.exists(dirs):
        os.makedirs(dirs)
    file_obj = open(file_path, 'wb')
    cPickle.dump(obj, file_obj)
    file_obj.close()


def deserialize_file(file_path):
    file_obj = open(file_path, 'rb')
    try:
        return_val = cPickle.load(file_obj)
    except:
        print "exception"
        return_val = None
    finally:
        file_obj.close()
    return return_val


def parse_json_str(json_str):
    return simplejson.loads(json_str)


def parse_json_file(file_path):
    file_obj = open(file_path, 'r')
    change_str = file_obj.read()
    file_obj.close()
    change_data = parse_json_str(change_str)
    return change_data


def subsystem_of(file_path):
    str_list = file_path.split('/')
    if len(str_list) == 1:
        return ''
    else:
        if str_list[0] == '':
            return str_list[1]
        return str_list[0]


def directory_of(file_path):
    return os.path.dirname(file_path)
