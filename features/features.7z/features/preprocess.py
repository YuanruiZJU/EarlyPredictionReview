import project_set
import time
import global_variable


def serialize_project_sets():
    start = time.clock()
    for p_set in ['openstack']:
        p_set = project_set.ProjectSet(p_set)
        p_set.serialize()
        #p_set.serialize_sub_projects_map()
    end = time.clock()
    print "total time: %f s" % (end - start)


def serialize_sub_projects_change_map(p_set_name):
    start = time.clock()
    sub_projects = global_variable.candidate_sub_project[p_set_name]
    p_set = project_set.deserialize_file(p_set_name, 'serialize_file')
    assert(isinstance(p_set, project_set.ProjectSet))
    for project in sub_projects:
        print '%s start' % project
        p_set.sub_project_sorted_change_maps(project, root_project=True)
    end = time.clock()
    print "total time: %f s" % (end-start)


def serialize_change_maps(p_set_name):
    start = time.clock()
    p_set = project_set.deserialize_file(p_set_name, 'serialize_file')
    assert(isinstance(p_set, project_set.ProjectSet))
    print 'serialize sorted change map!'
    p_set.serialize_sorted_change_map(filter_changes=True, filter_abandoned_ratio=0.0)
    print 'serialize people change map'
    p_set.serialize_people_change_map()
    print 'serialize_message_change_map'
    p_set.serialize_message_map()
    end = time.clock()
    print 'total time: %f s' % (end -  start)


def serialize_people_change_map(p_set_name):
    start = time.clock()
    p_set = project_set.deserialize_file(p_set_name, 'serialize_file')
    assert (isinstance(p_set, project_set.ProjectSet))
    p_set.serialize_people_change_map()
    end = time.clock()
    print 'total time: %f s' % (end - start)


if __name__ == "__main__":
    # serialize_project_sets()
    # serialize_change_maps('openstack')
    # serialize_sub_projects_change_map('eclipse')
    for p_set_name in ['eclipse', 'libreoffice', 'openstack']:
        p_set = project_set.deserialize_file(p_set_name, 'serialize_file')
        print len(p_set.review_data_set)
