import os
import sys

import global_variable
import project_set

sys.path.append(global_variable.my_code_project_dir)
reviewer_dir_path = global_variable.reviewer_dir_path


def mk_reviewer_dir():
    if not os.path.exists(reviewer_dir_path):
        os.mkdir(reviewer_dir_path)
    for p_set in global_variable.project_sets:
        p_set_path = reviewer_dir_path + p_set
        if not os.path.exists(p_set_path):
            os.mkdir(p_set_path)
        merged_path = p_set_path + '/' + 'merged'
        abandoned_path = p_set_path + '/' + 'abandoned'
        if not os.path.exists(merged_path):
            os.mkdir(merged_path)
        if not os.path.exists(abandoned_path):
            os.mkdir(abandoned_path)


if __name__ == "__main__":
    mk_reviewer_dir()
    projects = global_variable.project_sets
    status = global_variable.status

    for p in projects:
        p_set = project_set.ProjectSet(p)
        for s in status:
            p_set.download_reviewers(s, 200)