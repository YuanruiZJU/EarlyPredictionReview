import simplejson
import requests
import os
import thread

import global_variable


projects = []
projects.append('eclipse')
#projects.append('aosp')
projects.append('libreoffice')
projects.append('openstack')
projects.append('gerrit')


statuses = []
statuses.append('merged')
statuses.append('abandoned')

download_dir = '/home/yyy/download_repositories/'

num_one_step = 100
urls = {}


def set_urls():
    urls['eclipse'] = 'https://git.eclipse.org/r/changes/?o=ALL_REVISIONS&o=ALL_FILES&o=ALL_COMMITS&o=MESSAGES&o=DETAILED_ACCOUNTS&n=%s' % num_one_step
    urls['aosp'] = 'https://android-review.googlesource.com/changes/?o=ALL_REVISIONS&o=ALL_FILES&o=ALL_COMMITS&o=MESSAGES&o=DETAILED_ACCOUNTS&n=%s' % num_one_step
    urls['libreoffice'] = 'https://gerrit.libreoffice.org/changes/?o=ALL_REVISIONS&o=ALL_FILES&o=ALL_COMMITS&o=MESSAGES&o=DETAILED_ACCOUNTS&n=%s' % num_one_step
    urls['openstack'] = 'https://review.openstack.org/changes/?o=ALL_REVISIONS&o=ALL_FILES&o=ALL_COMMITS&o=MESSAGES&o=DETAILED_ACCOUNTS&n=%s' % num_one_step
    urls['gerrit'] = 'https://review.gerrithub.io/changes/?o=ALL_REVISIONS&o=ALL_FILES&o=ALL_COMMITS&o=MESSAGES&o=DETAILED_ACCOUNTS&n=%s' % num_one_step


def get_changes(project, start_index, status):
    projects = urls.keys()
    changeStr = ''
    if project in projects:
        url = urls[project]
        url = url + '&q=status:%s&S=%s' % (status, start_index)
        #print url
        changeStr = requests.get(url).content[4:]
    return changeStr


def project_dir(project, status):
    dir_path = download_dir + project
    if(os.path.exists(dir_path) == False):
        os.mkdir(dir_path)
    dir_path = dir_path + '/' + status
    if(os.path.exists(dir_path) == False):
        os.mkdir(dir_path)


def mkdir_for_projects():
    for p in projects:
        for s in statuses:
            project_dir(p, s)


def remove_all_logs():
    for p in projects:
        for s in statuses:
            path = p + '-' + s + '.log'
            if(os.path.exists(path)):
                os.remove(path)


def write_file(file_path, message):
    file_obj = open(file_path, 'w+')
    file_obj.write(message+'\n')
    file_obj.close()


def download(project, status, start_index=0, one_step=100):
    print project + ": " + status + " download"
    has_more = True
    dir_path = download_dir + project + '/' + status + '/'

    logfile_name = global_variable.log_path + project + '-' + status + '.log'
    log_obj = open(logfile_name, 'a+')

    log_obj.write('start log\n')
    try_num = 3
    while(has_more):
        try:
            file_path = dir_path + '%s-%s.json' % (start_index, start_index + num_one_step - 1)

            if(os.path.exists(file_path)):
                start_index = start_index + one_step
                continue

            #print file_path
            #print "start_download"
            changeStr = get_changes(project, start_index, status)
            changeJson = simplejson.loads(changeStr)
            if(len(changeJson) == 0):
                break

            write_file(file_path, changeStr)
            log_message = '%s %s %s to %s has downloaded!' % (project, status, start_index, start_index+num_one_step-1)
            log_obj.write(log_message+'\n')
            print log_message
            start_index = start_index + one_step
        except:
            if(try_num > 0):
                try_num = try_num - 1
            else:
                try_num = 3
                log_message = '%s %s %s to %s exception!' % (project, status, start_index, start_index + num_one_step - 1)
                print log_message
                log_obj.write(log_message+'\n')
                start_index = start_index + one_step
            pass
    log_obj.write('end log\n')
    print project + " end"
    log_obj.close()



#mkdirForProjects()
#remove_all_logs()
set_urls()

try:
    for p in projects:
        for s in statuses:
            i = 0
            while (i<100):
                thread.start_new_thread(download, (p,s,i,100,))
                i = i + 100
except:
   print "Error: unable to start thread"

while True:
    pass
