import sys
sys.path.append('/home/yyy/PycharmProjects/MiningCodeReviews/')

import project_set

import multiprocessing


def download_multiprocess_one_sub_project(project_set_name, sub_project_name):

    sub_project_map = project_set.deserialize_sub_projects_map(project_set_name)
    sub_project_map[sub_project_name].multi_process_fetch_changes()


def download_git_repo(p_set_name, process_index=0, process_number=1):
    print "process_index: %s" % process_index

    num_project = 0
    sub_project_map = project_set.deserialize_sub_projects_map(p_set_name)

    for sub_p in sub_project_map.keys():
        if num_project % process_number != process_index:
            num_project += 1
            continue
        if sub_project_map[sub_p].end_download == True:
            num_project += 1
            continue
        sub_project_map[sub_p].fetch_all_change()
        num_project += 1


def get_downloaded_change_number(p_set_name):
    sub_project_map = project_set.deserialize_sub_projects_map(p_set_name)
    changes_num = 0
    for sub_p in sub_project_map.keys():
        # if sub_project_map[sub_p].end_download == True:
        #     changes_num += len(sub_project_map[sub_p].refs)
        # else:
        downloaded_number = sub_project_map[sub_p].get_downloaded_changes_number()
        changes_num += downloaded_number
        print changes_num
    project_set.quick_serialize_sub_projects_map(p_set_name, sub_project_map)
    print "%s : %s" % (p_set_name, changes_num)


def get_filtered_change_number(p_set_name, min_change_number):
    sub_project_map = project_set.deserialize_sub_projects_map(p_set_name)
    changes_num = 0
    for sub_p in sub_project_map.keys():
        if len(sub_project_map[sub_p].refs) < min_change_number:
            continue

        changes_num += len(sub_project_map[sub_p].refs)

    print changes_num


def get_total_change_number(p_set_name):
    sub_project_map = project_set.deserialize_sub_projects_map(p_set_name)
    number = 0
    for sub_p in sub_project_map.keys():
        number += len(sub_project_map[sub_p].refs)
    print number


def get_sub_project_change_number(p_set_name, sub_project_name):
    sub_project_map = project_set.deserialize_sub_projects_map(p_set_name)
    print len(sub_project_map[sub_project_name].refs)


def multi_process_download_git_repo(p_set_name, process_number):
    i = 0
    processes = []
    while i < process_number:
        p1 = multiprocessing.Process(target=download_git_repo, args=(p_set_name, i, process_number,))
        processes.append(p1)
        p1.start()
        i += 1

    i = 0
    while i < process_number:
        processes[i].join()
        i += 1


def get_downloaded_one_project_change_number(project_set_name, sub_project_name):
    sub_project_map = project_set.deserialize_sub_projects_map(project_set_name)
    number = sub_project_map[sub_project_name].get_downloaded_changes_number()
    print number
    return number


def get_undownloaded_sub_projects(project_set_name):
    map_changed = False
    sub_project_map = project_set.deserialize_sub_projects_map(project_set_name)
    for sub_p_name in sub_project_map.keys():
        if not sub_project_map[sub_p_name].end_download:
            if get_downloaded_one_project_change_number(project_set_name, sub_p_name) == len(sub_project_map[sub_p_name].refs):
                sub_project_map[sub_p_name].end_download = True
                map_changed = True
                continue
            print sub_p_name

    if map_changed:
        project_set.quick_serialize_sub_projects_map(project_set_name, sub_project_map)


if __name__=="__main__":
    # download_git_repo('openstack', 0, 1)
    # get_downloaded_change_number('eclipse')
    get_downloaded_change_number('openstack')
    get_total_change_number('openstack')
    # get_filtered_change_number('openstack', 1)
    # multi_process_download_git_repo('openstack', 20)
    # download_multiprocess_libreoffice_core()
    # get_sub_project_change_number('openstack', 'openstack/nova')
    # download_multiprocess_one_sub_project('openstack', 'openstack/openstack-manuals')
    # get_downloaded_one_project_change_number('openstack', 'openstack/nova')
    # get_undownloaded_sub_projects('openstack')
