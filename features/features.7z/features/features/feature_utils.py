from features import exceptions as feature_exception
import project_set
import revision
import math
import datetime


people_change_maps = {}


def get_people_change_map(p_set_name, sub_project_name=None):
    global people_change_maps
    key = p_set_name
    if sub_project_name is not None:
        key = key + '_' + sub_project_name
    try:
        ret_val = people_change_maps[key]
    except KeyError:
        people_change_maps[key] = project_set.deserialize_file(p_set_name,
                                                               'people_change_map',
                                                               sub_project_name)
        ret_val = people_change_maps[key]
    return ret_val


sorted_change_maps = {}


def get_sorted_change_map(p_set_name, sub_project_name=None):
    global sorted_change_maps
    key = p_set_name
    if sub_project_name is not None:
        key = key + '_' + sub_project_name
    try:
        ret_val = sorted_change_maps[key]
    except KeyError:
        sorted_change_maps[key] = project_set.deserialize_file(p_set_name,
                                                               'sorted_change_map',
                                                               sub_project_name)
        ret_val = sorted_change_maps[key]
    return ret_val


message_maps = {}


def get_message_map(p_set_name, sub_project_name=None):
    global message_maps
    key = p_set_name
    if sub_project_name is not None:
        key = key + '_' + sub_project_name
    try:
        ret_val = message_maps[key]
    except KeyError:
        message_maps[key] = project_set.deserialize_file(p_set_name,
                                                         'message_map',
                                                         sub_project_name)
        ret_val = message_maps[key]
    return ret_val


###################################################################
def compare_time(time_str1, current_time):
    year1 = int(time_str1.split('-')[0])
    year2 = int(current_time.split('-')[0])
    month1 = int(time_str1.split('-')[1])
    month2 = int(current_time.split('-')[1])

    delta_year = year2 - year1
    if month2 < month1:
        delta_year -= 1
    return delta_year


def day_of(time_str):
    y_m_d = time_str.split(' ')[0]
    return int(y_m_d.split('-')[-1])


def log2(x):
    assert(x > 0)
    return math.log(x, 2)


def delta_days(updated_time_str, created_time_str):
    y_m_d_updated = updated_time_str.split(' ')[0]
    y_m_d_created = created_time_str.split(' ')[0]
    h_m_s_updated = updated_time_str.split(' ')[1].split('.')[0]
    h_m_s_created = created_time_str.split(' ')[1].split('.')[0]
    year_updated = int(y_m_d_updated.split('-')[0])
    year_created = int(y_m_d_created.split('-')[0])
    month_updated = int(y_m_d_updated.split('-')[1])
    month_created = int(y_m_d_created.split('-')[1])
    day_updated = int(y_m_d_updated.split('-')[-1])
    day_created = int(y_m_d_created.split('-')[-1])
    hour_updated = int(h_m_s_updated.split(':')[0])
    hour_created = int(h_m_s_created.split(':')[0])
    min_updated = int(h_m_s_updated.split(':')[1])
    min_created = int(h_m_s_created.split(':')[1])
    second_updated = int(h_m_s_updated.split(':')[-1])
    second_created = int(h_m_s_created.split(':')[-1])
    updated_time = datetime.datetime(year_updated, month_updated, day_updated, hour_updated, min_updated, second_updated)
    created_time = datetime.datetime(year_created, month_created, day_created, hour_created, min_created, second_created)
    return (updated_time - created_time).days


#######################################################################
def segments_maps(lines, start_line, end_line):
    segments_lines= []
    i = start_line
    index = 0
    while i < end_line:
        this_line = lines[i]
        try:
            if this_line[0:2] == '@@':
                segments_lines.append({})
                segments_lines[index]['start_line'] = i + 1
                if index > 0:
                    segments_lines[index-1]['end_line'] = i
                index += 1
        except IndexError:
            pass
        i += 1
    if index > 0:
        segments_lines[index - 1]['end_line'] = end_line

    return segments_lines


def check_update_type(lines, start_line, end_line):
    i = start_line
    has_plus = False
    has_minus = False
    while i < end_line:
        this_line = lines[i]
        try:
            if this_line[0] == '+':
                has_plus = True
        except IndexError:
            i += 1
            continue
        if this_line[0] == '-':
            has_minus = True
        i += 1

    return has_plus, has_minus


def get_file_line(lines, start, end, add_or_del=False):
    i = start
    while i < end:
        this_line = lines[i]
        if this_line[0:2] == '@@':
            file_info = this_line.split(' ')
            if add_or_del:
                assert (file_info[1] == '-0,0' or file_info[1] == '-1,0')
                info_lists = file_info[-2].split(',')
                assert(info_lists[0] == '+1')
                try:
                    return int(info_lists[1])
                except IndexError:
                    return -100
            else:
                assert(file_info[-2] == '+0,0')
                info_lists = file_info[1].split(',')
                assert(info_lists[0] == '-1')
                try:
                    return int(info_lists[1])
                except IndexError:
                    return -100
        i += 1
    return 0


def parse_git_show_file(lines, files):
    n_lines = len(lines)
    i = 0
    file_diff_map = {}
    files_info = {}

    last_file_path = None
    file_diff_map['_deleted_files_'] = []
    file_diff_map['_added_files_'] = []
    file_diff_map['_renamed_files_'] = []
    file_diff_map['_updated_files_'] = []
    file_diff_map['_file_paths_'] = []

    for f in files:
        assert(isinstance(f, revision.File))
        files_info[f.file_path] = {}
        files_info[f.file_path]['insertions'] = f.insertions
        files_info[f.file_path]['deletions'] = f.deletions

    file_paths = files_info.keys()

    while i < n_lines-1:
        this_line = lines[i]
        next_line = lines[i + 1]
        try:
            if this_line[0:3] == '---' and next_line[0:3] == '+++':
                if this_line == '--- /dev/null':
                    file_path = next_line[6:]
                    file_diff_map['_added_files_'].append(file_path)
                elif next_line == '+++ /dev/null':
                    file_path = this_line[6:]
                    file_diff_map['_deleted_files_'].append(file_path)
                else:
                    first_file_path = this_line[6:]
                    next_file_path = next_line[6:]
                    while first_file_path[-1] in [' ', '\t']:
                        first_file_path = first_file_path[:-1]
                    while next_file_path[-1] in [' ', '\t']:
                        next_file_path = next_file_path[:-1]
                    if first_file_path == next_file_path:
                        file_path = first_file_path
                        file_diff_map['_updated_files_'].append(file_path)
                    else:
                        file_path = next_file_path
                        file_diff_map['_renamed_files_'].append(file_path)
                file_diff_map['_file_paths_'].append(file_path)
                file_diff_map[file_path] = {}
                file_diff_map[file_path]['start_line'] = i
                if last_file_path is not None:
                    j = i - 1
                    while lines[j][0:4] != 'diff':
                        j -= 1
                    file_diff_map[last_file_path]['end_line'] = j
                last_file_path = file_path
        except IndexError:
            pass
        i += 1
    if last_file_path is not None:
        file_diff_map[last_file_path]['end_line'] = n_lines

    for added_file in file_diff_map['_added_files_']:
        if added_file in file_paths:
            insertions = files_info[added_file]['insertions']
            deletions = files_info[added_file]['deletions']
            if deletions > 0:
                file_diff_map['_renamed_files_'].append(added_file)
            else:
                start = file_diff_map[added_file]['start_line']
                end = file_diff_map[added_file]['end_line']
                file_insertion_from_git = get_file_line(lines, start, end, True)
                if insertions < file_insertion_from_git:
                    file_diff_map['_renamed_files_'].append(added_file)

    for f_path in file_diff_map['_renamed_files_']:
        try:
            file_diff_map['_added_files_'].remove(f_path)
        except ValueError:
            pass

    for path in file_paths:
        if path not in file_diff_map['_file_paths_']:
            if files_info[path]['insertions'] == 0 and \
                            files_info[path]['deletions'] == 0:
                continue
            raise feature_exception.NotConsistentException

    return file_diff_map


###########################################################################################
def get_all_projects_and_branch_names(p_set_name):
    sorted_change_map = get_sorted_change_map(p_set_name)
    sub_project_sets = set()
    branch_sets = set()
    i = 0
    len_sorted = len(sorted_change_map)
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        sub_project_sets.add(ch.project)
        branch_sets.add(ch.branch)
        i += 1
    sub_projects_str = '{'
    branches_str = '{'
    for p in sub_project_sets:
        sub_projects_str += p
        sub_projects_str += ','
    for b in branch_sets:
        branches_str += b
        branches_str += ','
    sub_projects_str = sub_projects_str[:-1] + '}'
    branches_str = branches_str[:-1] + '}'

    return {'project_name': sub_projects_str,
            'branch_name': branches_str}

#########################################################################
