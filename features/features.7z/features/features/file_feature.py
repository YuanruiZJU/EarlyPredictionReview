from features import Features

import global_variable
import code_review


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    fields = global_variable.feature_dict['file_features']
    for key in fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


file_feature_maps = {}


def get_file_feature_map(p_set_name, sub_project_name, file_path):
    empty_set = set()
    try:
        file_feature_maps[p_set_name]
    except KeyError:
        file_feature_maps[p_set_name] = {}
    try:
        file_feature_maps[p_set_name][sub_project_name]
    except KeyError:
        file_feature_maps[p_set_name][sub_project_name] = {}

    try:
        file_feature_maps[p_set_name][sub_project_name][file_path]
    except KeyError:
        file_feature_maps[p_set_name][sub_project_name][file_path] = {'modify_changes': set(),
                                                          'developer': empty_set}
    return file_feature_maps[p_set_name][sub_project_name][file_path]


class FileFeatures(Features):

    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['file_features']

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(FileFeatures, self).__init__(change_number)
        self.status = simple_code_review.status
        self.feature_fields = self.get_feature_fields()
        self.use_global_file_map = {}
        self.owner = simple_code_review.owner
        self.project = simple_code_review.project
        for f in simple_code_review.files:
            if f.insertions + f.deletions == 0:
                continue
            file_path = f.file_path
            self.use_global_file_map[file_path] = get_file_feature_map(p_set_name, self.project, file_path)

    def extract_features(self):
        modify_changes = set()
        developers = set()
        for file_path in self.use_global_file_map.keys():
            # this_modify_times = self.use_global_file_map[file_path]['modify_times']
            # if this_modify_times > self['file_modify_times']:
            #     self['max_file_modify_times'] = this_modify_times
            # this_developer_num = len(self.use_global_file_map[file_path]['developer'])
            # if this_developer_num > self['max_developer']:
            #     self['max_developer'] = this_developer_num
            # if self.status == 'MERGED':
            #     self.use_global_file_map[file_path]['modify_times'] += 1
            #     self.use_global_file_map[file_path]['developer'].add(self.owner)
            file_modify_changes = self.use_global_file_map[file_path]['modify_changes']
            modify_changes |= file_modify_changes
            file_developers = self.use_global_file_map[file_path]['developer']
            developers |= file_developers
            self.use_global_file_map[file_path]['modify_changes'].add(self.change_number)
            self.use_global_file_map[file_path]['developer'].add(self.owner)

        self['changes_files_modified'] = len(modify_changes)
        self['file_developer_num'] = len(developers)

