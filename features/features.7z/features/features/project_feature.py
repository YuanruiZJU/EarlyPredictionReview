import code_review
import global_variable
from features import Features
from features import feature_utils


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    fields = global_variable.feature_dict['project_features']
    for key in fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class ProjectFeatures(Features):
    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['project_features']

    def __init__(self, p_set_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(ProjectFeatures, self).__init__(change_number)
        self.feature_fields = self.get_feature_fields()
        self.status = simple_code_review.status
        self.subsystems = simple_code_review.subsystems
        self.files = simple_code_review.files
        self.owner = simple_code_review.owner
        self.project = simple_code_review.project
        self.created = simple_code_review.created
        self.sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, self.project)

    def extract_features(self):
        number = self.change_number - 1
        self['recent_merged_ratio'] = 0
        abandoned = 0
        merged = 0
        while number > 0:
            try:
                ch = self.sorted_change_map[number]
            except KeyError:
                number -= 1
                continue
            created = ch.created
            delta_days = feature_utils.delta_days(self.created, created)
            if delta_days > 0 and delta_days < 30:
                if ch.status == 'MERGED':
                    merged += 1
                else:
                    abandoned += 1
            number -= 1
        if merged == 0 and abandoned == 0:
            return
        self['recent_merged_ratio'] = merged / (merged + abandoned)
