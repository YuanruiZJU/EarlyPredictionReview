from features import Features
from features import feature_utils
import code_review
import global_variable

import os
import re
import nltk


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    true_false = '{True,False}'
    fields = global_variable.feature_dict['message_features']
    for key in fields:
        attributes[key] = true_false

    attributes['msg_length'] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


def add_headers_to_message_arff_path(arff_path):
    attributes = {}
    fields = ['_status_', 'commit_message']
    attributes['_status_'] = '{MERGED,ABANDONED}'
    attributes['commit_message'] = 'String'
    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


def create_msg_arff_file(arff_path, start_change_num , change_num, p_set_name, sub_project_name):
    pass


class CommitMessageFeatures(Features):
    """"
    'message_features': ['msg_length'],
    """

    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['message_features']

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(CommitMessageFeatures, self).__init__(change_number)
        self.status = simple_code_review.status
        self.feature_fields = self.get_feature_fields()
        self.msg = feature_utils.\
            get_message_map(p_set_name, sub_project_name)[self.change_number]
        self.subject = simple_code_review.subject

    def extract_features(self):
        self['msg_length'] = 0
        self['has_bug'] = False
        self['has_feature'] = False
        self['has_improve'] = False
        self['has_document'] = False
        self['has_refactor'] = False

        s = nltk.stem.SnowballStemmer('english')
        msg_words = nltk.word_tokenize(self.msg)
        self['msg_length'] = len(msg_words)
        for word in msg_words:
            stem_w = s.stem(word)
            if stem_w == 'bug':
                self['has_bug'] = True
            if stem_w == 'improv':
                self['has_improve'] = True
            if stem_w == 'featur':
                self['has_feature'] = True
            if stem_w == 'document':
                self['has_document'] = True
            if stem_w == 'refactor':
                self['has_refactor'] = True

    def msg_to_arff(self, arff_path, relation):
        def delete_control_char(s):
            s = s.replace('\x00', ' ')
            s = s.replace('\x01', ' ')
            s = s.replace('\x02', ' ')
            s = s.replace('\x03', ' ')
            s = s.replace('\x04', ' ')
            s = s.replace('\x05', ' ')
            s = s.replace('\x06', ' ')
            s = s.replace('\x07', ' ')
            s = s.replace('\x08', ' ')
            s = s.replace('\x09', ' ')
            s = s.replace('\x0a', ' ')
            s = s.replace('\x0b', ' ')
            s = s.replace('\x0c', ' ')
            s = s.replace('\x0d', ' ')
            s = s.replace('\x0e', ' ')
            s = s.replace('\x0f', ' ')
            s = s.replace('\x10', ' ')
            s = s.replace('\x11', ' ')
            s = s.replace('\x12', ' ')
            s = s.replace('\x13', ' ')
            s = s.replace('\x14', ' ')
            s = s.replace('\x15', ' ')
            s = s.replace('\x16', ' ')
            s = s.replace('\x17', ' ')
            s = s.replace('\x18', ' ')
            s = s.replace('\x19', ' ')
            s = s.replace('\x1a', ' ')
            s = s.replace('\x1b', ' ')
            s = s.replace('\x1c', ' ')
            s = s.replace('\x1d', ' ')
            s = s.replace('\x1e', ' ')
            s = s.replace('\x1f', ' ')
            return s
        import sys
        reload(sys)
        sys.setdefaultencoding('utf-8')
        if not os.path.exists(arff_path):
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()

            add_headers_to_message_arff_path(arff_path)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()
        processed_msg = self.msg.replace('\n', ' ')
        processed_msg = processed_msg.replace('"', "'")
        processed_msg = delete_control_char(processed_msg)
        file_obj = open(arff_path, 'a+')
        file_obj.write(self.status + ',"' + processed_msg + '"' + '\n')
        file_obj.close()

