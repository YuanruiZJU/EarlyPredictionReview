"""
Feature Classes
"""
import os
import csv
import global_variable


global_maps = {}


def register_features_map(f_map):
    global global_maps
    assert(isinstance(f_map, ProjectSetFeaturesMap))
    global_maps[f_map.project_set_name] = f_map


def get_features_map(p_set_name):
    if p_set_name in global_maps.keys():
        return global_maps[p_set_name]
    return None


class Features(object):

    @staticmethod
    def get_feature_fields():
        return []

    def __init__(self, change_number):
        self.change_number = change_number
        self.status = None
        self.feature_fields = []
        self.items_dict = {}
        self.to_file_features = {}

    def __setitem__(self, key, value):
        if key in self.feature_fields:
            self.items_dict[key] = value

    def __getitem__(self, key):
        if key in self.items_dict.keys():
            return self.items_dict[key]
        return None

    def add_features(self, fs):
        assert(isinstance(fs, Features))
        if self.change_number == fs.change_number:
            self.items_dict = dict(self.items_dict, **fs.items_dict)
            self.feature_fields = self.items_dict.keys()
        if self.status is None and fs.status is not None:
            self.status = fs.status

    def add_features_from_dict(self, features_dict):
        assert(isinstance(features_dict, dict))
        self.items_dict = dict(self.items_dict, **features_dict)
        self.feature_fields = self.items_dict.keys()

    def print_features(self):
        print '%s   %s' % (self.status, self.change_number),
        for field in self.items_dict.keys():
            print "%s: %s  " % (field, self.items_dict[field]),
        print '\n',

    def to_dict(self, fields=None):
        if fields is None:
            return self.items_dict.copy()
        else:
            result_dict = dict()
            for field in fields:
                field_variable = self.items_dict[field]
                if isinstance(field_variable, type(True)):
                    if field_variable:
                        field_variable = 1
                    else:
                        field_variable = 0
                result_dict[field] = field_variable
            return result_dict

    def to_arff(self, arff_path, p_set_name, sub_project_name, relation,
                is_baseline=False, is_icse=False):
        def write_arff_header(arff_path, p_set_name, relation):
            import simple_feature
            import code_feature
            import file_feature
            import author_feature
            import message_feature
            import project_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            simple_feature.add_headers_to_arff_path(arff_path, p_set_name)
            code_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_feature.add_headers_to_arff_path(arff_path, p_set_name)
            author_feature.add_headers_to_arff_path(arff_path, p_set_name)
            message_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        def write_baseline_arff_header(arff_path, p_set_name, sub_project_name, relation):
            from baseline_features import baseline_metadata_feature
            from baseline_features import baseline_code_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            baseline_metadata_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            baseline_code_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        def write_icse_arff_header(arff_path, p_set_name, sub_project_name, relation):
            from icse_paper_features import pull_request_features
            from icse_paper_features import project_feature
            from icse_paper_features import developer_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            pull_request_features.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            project_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            developer_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        # sequence simple/code/file/author/message
        fields = []
        if (not is_baseline) and (not is_icse):
            fields = global_variable.feature_dict['simple_features'] + \
                global_variable.feature_dict['code_features'] + \
                global_variable.feature_dict['file_features'] + \
                global_variable.feature_dict['author_features']['personal'] + \
                global_variable.feature_dict['author_features']['social'] + \
                global_variable.feature_dict['message_features']

        if is_baseline and (not is_icse):
            code_feature_fields = []
            for lang in global_variable.language_project_map[p_set_name]:
                try:
                    code_feature_fields += global_variable.baseline_features_dict['code_features'][lang]
                except KeyError:
                    pass
            fields = global_variable.baseline_features_dict['meta_data_features'] + \
                code_feature_fields
        if is_icse and (not is_baseline):
            fields = global_variable.icse_feature_dict['pull_request'] + \
                global_variable.icse_feature_dict['project'] + \
                global_variable.icse_feature_dict['developer']

        if not os.path.exists(arff_path):
            if (not is_baseline) and (not is_icse):
                write_arff_header(arff_path, p_set_name, relation)
            elif is_baseline and (not is_icse):
                write_baseline_arff_header(arff_path, p_set_name, sub_project_name, relation)
            elif is_icse and (not is_baseline):
                write_icse_arff_header(arff_path, p_set_name, sub_project_name, relation)

        this_line = ""
        try:
            for field in fields:
                this_line += str(self.items_dict[field])
                this_line += ','
        except KeyError:
            return
        this_line = this_line[:-1]

        file_obj = open(arff_path, 'a+')
        file_obj.write(this_line)
        file_obj.write('\n')
        file_obj.close()


class ProjectSetFeaturesMap:

    def __init__(self, project_set_name, sub_project_name):
        self.project_set_name = project_set_name
        self.sub_project_name = sub_project_name

        self._features_map = {}
        register_features_map(self)

    def add_features(self, fs):
        assert(isinstance(fs, Features))
        change_number = fs.change_number
        try:
            self._features_map[change_number].add_features(fs)
        except KeyError:
            self._features_map[change_number] = Features(change_number)
            self._features_map[change_number].add_features(fs)

    def add_features_from_map(self, features_map):
        i = 1
        num = 0
        len_map = len(features_map)
        while num < len_map:
            try:
                features_map[i]
            except KeyError:
                i += 1
                continue
            num += 1
            change_number = i
            try:
                self._features_map[change_number].add_features_from_dict(features_map[change_number])
            except KeyError:
                self._features_map[change_number] = Features(change_number)
                self._features_map[change_number].add_features_from_dict(features_map[change_number])
            i += 1

    def print_features(self, change_number):
        self._features_map[change_number].print_features()

    def is_valid_change(self, change_number, feature_fields):
        try:
            feature_map = self._features_map[change_number].items_dict
        except KeyError:
            return False
        for field in feature_fields:
            try:
                feature_map[field]
            except KeyError:
                return False
        try:
            feature_map['segs_added_num']
        except KeyError:
            return False
        return True

    def partial_to_arff(self, arff_path, start_change_number, change_num, relation,
                        valid_change_numbers, is_baseline=False, is_icse=False):
        if os.path.exists(arff_path):
            os.remove(arff_path)
        ch_no = start_change_number
        num = 0
        while num < change_num:
            if ch_no not in valid_change_numbers:
                ch_no += 1
                continue
            try:
                self._features_map[ch_no].to_arff(arff_path, self.project_set_name,
                                                  self.sub_project_name,
                                                  relation=relation,
                                                  is_baseline=is_baseline,
                                                  is_icse=is_icse)
                num += 1
            except KeyError:
                pass
            ch_no += 1
        return ch_no

    def to_csv(self, csv_path, start_change_no, valid_change_numbers, fields):
        if not os.path.exists(csv_path):
            csv_file = open(csv_path, 'w')
            writer = csv.DictWriter(csv_file, fieldnames=fields)
            writer.writeheader()
            csv_file.close()
        csv_file = open(csv_path, 'a+')
        writer = csv.DictWriter(csv_file, fieldnames=fields)
        ch_no = start_change_no
        num = 0
        change_num = len(valid_change_numbers)
        while num < change_num:
            if ch_no not in valid_change_numbers:
                ch_no += 1
                continue
            row_dict = self._features_map[ch_no].to_dict(fields=fields)
            writer.writerow(row_dict)
            num += 1
            ch_no += 1
        csv_file.close()

    def to_arff(self, arff_path, start_change_no, valid_change_numbers, fields):
        def write_arff_header(arff_path, p_set_name, relation):
            import simple_feature
            import code_feature
            import file_feature
            import author_feature
            import message_feature
            import project_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            simple_feature.add_headers_to_arff_path(arff_path, p_set_name)
            code_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_feature.add_headers_to_arff_path(arff_path, p_set_name)
            author_feature.add_headers_to_arff_path(arff_path, p_set_name)
            message_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        def write_baseline_arff_header(arff_path, p_set_name, sub_project_name, relation):
            from baseline_features import baseline_metadata_feature
            from baseline_features import baseline_code_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            baseline_metadata_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            baseline_code_feature.add_headers_to_arff_path(arff_path, p_set_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        def write_icse_arff_header(arff_path, p_set_name, sub_project_name, relation):
            from icse_paper_features import pull_request_features
            from icse_paper_features import project_feature
            from icse_paper_features import developer_feature
            file_obj = open(arff_path, 'w')
            file_obj.write('@relation ' + relation + '\n\n')
            file_obj.close()
            pull_request_features.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            project_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            developer_feature.add_headers_to_arff_path(arff_path, p_set_name, sub_project_name)
            file_obj = open(arff_path, 'a+')
            file_obj.write('\n')
            file_obj.write('@data\n')
            file_obj.close()

        if not os.path.exists(arff_path):
            # write_arff_header(arff_path, self.project_set_name, self.project_set_name)
            write_baseline_arff_header(arff_path, self.project_set_name, self.sub_project_name,
                                       self.project_set_name)
            # write_icse_arff_header(arff_path, self.project_set_name, self.sub_project_name,
            #                        self.project_set_name)
        ch_no = start_change_no
        num = 0
        change_num = len(valid_change_numbers)
        while num < change_num:
            if ch_no not in valid_change_numbers:
                ch_no += 1
                continue
            this_line = ""
            try:
                for field in fields:
                    this_line += str(self._features_map[ch_no].items_dict[field])
                    this_line += ','
            except KeyError:
                ch_no += 1
                continue
            this_line = this_line[:-1]
            file_obj = open(arff_path, 'a+')
            file_obj.write(this_line)
            file_obj.write('\n')
            file_obj.close()
            num += 1
            ch_no += 1





