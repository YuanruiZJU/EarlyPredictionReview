from features import Features
from features import feature_utils
import code_review
import global_variable


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    for key in global_variable.feature_dict['simple_features']:
        attributes[key] = numeric_attr

    # if 'project_name' in global_variable.feature_dict['simple_features']:
    #     project_branch_map = feature_utils.get_all_projects_and_branch_names(p_set_name)
    #     attributes['project_name'] = project_branch_map['project_name']
    #     attributes['branch_name'] = project_branch_map['branch_name']
    attributes['status'] = '{ABANDONED,MERGED}'

    f_obj = open(arff_path, 'a+')
    for key in global_variable.feature_dict['simple_features']:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class SimpleFeatures(Features):

    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['simple_features']

    def __init__(self, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(SimpleFeatures, self).__init__(change_number)
        self.feature_fields = self.get_feature_fields()
        self.status = simple_code_review.status
        self.simple_code_review = simple_code_review

    def extract_features(self):
        assert(isinstance(self.simple_code_review, code_review.SimpleCodeReview))
        self['status'] = self.status
        self['change_number'] = self.change_number
        self['lines_added_num'] = 0
        self['lines_deleted_num'] = 0
        self['file_num'] = 0
        self['directory_num'] = len(self.simple_code_review.directories)
        self['subsystem_num'] = len(self.simple_code_review.subsystems)
        self['language_num'] = self.simple_code_review.get_language_num()
        self['file_type_num'] = self.simple_code_review.get_file_type_num()
        self['project_name'] = self.simple_code_review.project
        self['branch_name'] = self.simple_code_review.branch
        self['file_added_num'] = 0
        self['file_deleted_num'] = 0
        entropy = 0

        for f in self.simple_code_review.files:
            self['lines_added_num'] += f.insertions
            self['lines_deleted_num'] += f.deletions
            if not f.is_binary:
                if f.status == 'A':
                    self['file_added_num'] += 1
                elif f.status == 'D':
                    self['file_deleted_num'] += 1
            if f.insertions + f.deletions != 0:
                self['file_num'] += 1

        lines_modify = self['lines_added_num'] + self['lines_deleted_num']
        if lines_modify == 0:
            pass
        else:
            for f in self.simple_code_review.files:
                f_lines_modify = f.insertions + f.deletions
                if f_lines_modify == 0:
                    continue
                proportion = float(f_lines_modify) / float(lines_modify)
                entropy += - proportion * (feature_utils.log2(proportion))
        self['modify_entropy'] = entropy

        if self['lines_added_num'] > 0:
            self['lines_added_num'] = feature_utils.log2(float(self['lines_added_num'])) + 1
        if self['lines_deleted_num'] > 0:
            self['lines_deleted_num'] = feature_utils.log2(float(self['lines_deleted_num'])) + 1
