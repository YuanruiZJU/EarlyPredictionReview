from features import Features
from features import feature_utils
from features import social_networks
import global_variable
import code_review


person_reviewers_map = {}


def get_person_review_num(sub_project_name, person_id):
    global person_reviewers_map
    try:
        person_reviewers_map[person_id]
    except KeyError:
        person_reviewers_map[person_id] = 0
    return person_reviewers_map[person_id]


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    fields = global_variable.feature_dict['author_features']['personal'] + \
        global_variable.feature_dict['author_features']['social']
    for key in fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class AuthorPersonalFeatures(Features):
    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['author_features']['personal']

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(AuthorPersonalFeatures, self).__init__(change_number)
        self.feature_fields = self.get_feature_fields()
        self.status = simple_code_review.status
        owner = simple_code_review.owner
        self.owner = owner
        self.change_map = feature_utils.\
            get_people_change_map(p_set_name, sub_project_name)[owner]
        self.created = simple_code_review.created
        self.subsystems = simple_code_review.subsystems
        self.reviewers = simple_code_review.reviewers
        self.sorted_change_map = feature_utils.\
            get_sorted_change_map(p_set_name, sub_project_name)
        self.project = simple_code_review.project

    def extract_features(self):
        idx = 0
        merged_idx = 0
        recent_code_review_num = 0
        recent_code_review_merged = 0
        n_subsystem = 0
        n_subsystem_merged = 0
        # avg_author_lines_added = 0
        # avg_author_lines_deleted = 0

        change_map_len = len(self.change_map)
        num_processed = 0
        subsys_changes = set()
        merged_subsys_change = set()
        while num_processed < change_map_len:
            change_number = self.change_map[num_processed].change_number
            temp_change = self.sorted_change_map[change_number]
            num_processed += 1
            assert(isinstance(temp_change, code_review.SimpleCodeReview))
            # if temp_change.project != self.project:
            #     continue
            temp_created = temp_change.created
            temp_status = temp_change.status
            temp_subsystems = temp_change.subsystems
            if change_number == self.change_number:
                break
            else:
                delta_create_day = feature_utils.delta_days(self.created, temp_created)
                if delta_create_day < 0:
                    continue
                idx += 1
                if temp_status == 'MERGED':
                    # avg_author_lines_added += temp_change.insertions
                    # avg_author_lines_deleted += temp_change.deletions
                    merged_idx += 1

                if delta_create_day <= 120:
                    recent_code_review_num += 1.0 / (float(delta_create_day) / 30 + 1)
                    if temp_status == 'MERGED':
                        recent_code_review_merged += 1.0 / (float(delta_create_day) / 30 + 1)

                for subsys in self.subsystems:
                    if subsys in temp_subsystems:
                        # n_subsystem += 1
                        subsys_changes.add(temp_change.change_number)
                        if temp_status == 'MERGED':
                            merged_subsys_change.add(temp_change.change_number)
                        break
                            # n_subsystem_merged += 1

        n_subsystem = len(subsys_changes)
        n_subsystem_merged = len(merged_subsys_change)
        self['author_code_review_num'] = idx
        if idx != 0:
            self['author_merged_ratio'] = float(merged_idx) / float(idx)
        else:
            self['author_merged_ratio'] = 0
        self['author_recent_code_review_num'] = recent_code_review_num
        if recent_code_review_num != 0:
            self['author_recent_merged_ratio'] = recent_code_review_merged / recent_code_review_num
        else:
            self['author_recent_merged_ratio'] = 0
        self['author_subsystem_code_review_num'] = n_subsystem
        if n_subsystem != 0:
            self['author_subsystem_merged_ratio'] = float(n_subsystem_merged) / float(n_subsystem)
        else:
            self['author_subsystem_merged_ratio'] = 0
        self['author_reviewed_num'] = get_person_review_num(self.project, self.owner)
        # if merged_idx != 0:
        #     self['avg_lines_added_num'] = avg_author_lines_added / merged_idx
        #     self['avg_lines_deleted_num'] = avg_author_lines_deleted / merged_idx
        # else:
        #     self['avg_lines_added_num'] = 0
        #     self['avg_lines_deleted_num'] = 0
        for reviewer_id in self.reviewers:
            if reviewer_id == self.owner:
                continue
            else:
                try:
                    person_reviewers_map[reviewer_id] += 1
                except KeyError:
                    person_reviewers_map[reviewer_id] = 1


class AuthorSocialFeatures(Features):
    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['author_features']['social']

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(AuthorSocialFeatures, self).__init__(change_number)
        self.owner = simple_code_review.owner
        self.status = simple_code_review.status
        self.feature_fields = self.get_feature_fields()
        self.social_network = social_networks.SocialNetwork(p_set_name,
                                                            sub_project_name,
                                                            change_number)

    def extract_features(self):
        self['social_degree'] = round(self.social_network.degree_centrality(), 4)
        self['social_closeness'] = round(self.social_network.closeness_centrality(), 4)
        self['social_betweenness'] = round(self.social_network.betweenness_centrality(), 4)
        self['social_eigenvector'] = round(self.social_network.eigenvector_centrality(), 4)
        self['social_clustering'] = round(self.social_network.clustering_coefficient(), 4)
        self['social_k_coreness'] = round(self.social_network.k_coreness(), 4)

