import sys
import global_variable
import utils

sys.path.append('/Volumes/1/MyFirstPaper/code/MiningCodeReviews/')

from features import author_feature

from features import feature_utils


def extract_features(p_set_name, sub_project_name):
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    print 'start extract features.'
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        personal_features = author_feature.AuthorPersonalFeatures(p_set_name, sub_project_name, ch)

        personal_features.extract_features()
        personal_features.print_features()
        i += 1

def check_correct(p_set_name, sub_project_name):
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted = len(sorted_change_map)
    file_path = global_variable.serialize_file_path + p_set_name + '/features_maps/author_personal_map'
    personal_map = utils.deserialize_file(file_path)
    i = 1
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        print i
        num += 1
        fs = author_feature.AuthorPersonalFeatures(p_set_name, sub_project_name, ch)
        fs.extract_features()
        # fs.print_features()
        for key in personal_map[ch.change_number].keys():
            if fs[key] != personal_map[ch.change_number][key]:
                print "%s not consistent" % key
        i += 1

# extract_features('eclipse', None)

#author_feature.add_headers_to_arff_path('test.arff', 'eclipse')

check_correct('openstack', None)