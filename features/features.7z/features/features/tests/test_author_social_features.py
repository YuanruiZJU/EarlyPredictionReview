from features import author_feature

from features import feature_utils


def create_networks(p_set_name, sub_project_name):
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 1000
    num = 0
    print 'start creating networks.'
    social_features = None
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
            num += 1
            social_features = author_feature.AuthorSocialFeatures('eclipse', ch)
            print social_features.change_number
        except KeyError:
            pass
        i += 1
    print 'start show graph'
    social_features.social_network.show_graph()


def extract_features(p_set_name, sub_project_name):
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    print 'start extract features.'
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        print i
        personal_features = author_feature.AuthorSocialFeatures(p_set_name, sub_project_name, ch)
        personal_features.extract_features()
        personal_features.print_features()
        i += 1

if __name__ == '__main__':
    extract_features('eclipse', None)