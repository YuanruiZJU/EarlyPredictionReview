from features import file_feature

from features import feature_utils


def extract_features(p_set_name, sub_project_name):
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    print 'start extract features.'
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
            num += 1
            file_features = file_feature.FileFeatures(p_set_name, sub_project_name, ch)
            file_features.extract_features()
            file_features.print_features()
        except KeyError:
            pass
        i += 1

extract_features('eclipse', None)
