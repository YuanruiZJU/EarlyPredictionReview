import multiprocessing
import os
from features import feature_utils
from features import author_feature
import cPickle


def extract_one_change_feature(p_set_name, changes, process_index):
    my_map = {}
    my_path = 'temp_features/' + str(process_index)
    for ch in changes:
        print ch.change_number
        social_fs = author_feature.AuthorSocialFeatures(p_set_name, ch)
        social_fs.extract_features()
        my_map[ch.change_number] = social_fs.to_dict()
    file_obj = open(my_path, 'wb')
    cPickle.dump(my_map, file_obj)
    file_obj.close()


def mp_extract_author_social_features(p_set_name):
    temp_serialize_path = 'temp_features'
    process_number = 10
    if not os.path.exists(temp_serialize_path):
        os.mkdir(temp_serialize_path)

    process_change_map = {}
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name)
    len_change = len(sorted_change_map)
    num = 0
    i = 1
    while num < len_change:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        process_index = num % process_number
        try:
            process_change_map[process_index].append(ch)
        except KeyError:
            process_change_map[process_index] = []
            process_change_map[process_index].append(ch)
        num += 1
        i += 1
    i = 0
    processes = []
    while i < process_number:
        p1 = multiprocessing.Process(target=extract_one_change_feature, args=(p_set_name,process_change_map[i], i, ))
        p1.start()
        processes.append(p1)
        i += 1

    i = 0
    while i < process_number:
        processes[i].join()
        i += 1

mp_extract_author_social_features('eclipse')


