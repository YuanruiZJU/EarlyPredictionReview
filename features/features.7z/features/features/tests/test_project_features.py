from features import project_feature
from features import feature_utils

p_set_name = 'eclipse'
sub_project_name = 'jgit/jgit'

def extract_features():
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted = len(sorted_change_map)
    i = 0
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        project_fs = project_feature.ProjectFeatures(p_set_name, ch)
        project_fs.extract_features()
        project_fs.print_features()
        i += 1

extract_features()
