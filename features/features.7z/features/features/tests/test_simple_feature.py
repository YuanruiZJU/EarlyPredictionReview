from features import simple_feature

from features import feature_utils
import global_variable
import utils


def extract_features(p_set_name, sub_project_name):
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    file_path = global_variable.serialize_file_path + p_set_name + '/features_maps/simple_map'
    personal_map = utils.deserialize_file(file_path)
    i = 0
    num = 0
    print 'start extract features.'
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
            num += 1
            # if i == 21690:
            simple_features = simple_feature.SimpleFeatures(ch)
            simple_features.extract_features()
            simple_features.print_features()

            # for key in personal_map[ch.change_number].keys():
            #     if personal_map[ch.change_number][key] != simple_features[key]:
            #         print 'not consistent'

            # print personal_map[ch.change_number]['lines_added_num']

        except KeyError:
            pass
        i += 1

extract_features('eclipse', None)


#simple_feature.add_headers_to_arff_path('test.arff', 'eclipse')
