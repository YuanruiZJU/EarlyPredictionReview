from features import author_feature
from features import code_feature
from features import file_feature
from features import message_feature
from features import simple_feature
from features import project_feature

file_name = 'test.arff'
p_set_name = 'eclipse'
relation = 'train'
# sequence: simple\file\code\author\message


def write_arff_header(arff_path, p_set_name, relation):
    file_obj = open(arff_path, 'w')
    file_obj.write('@relation ' + relation + '\n\n')
    file_obj.close()

    simple_feature.add_headers_to_arff_path(arff_path, p_set_name)
    code_feature.add_headers_to_arff_path(arff_path, p_set_name)
    file_feature.add_headers_to_arff_path(arff_path, p_set_name)
    author_feature.add_headers_to_arff_path(arff_path, p_set_name)
    message_feature.add_headers_to_arff_path(arff_path, p_set_name)
    project_feature.add_headers_to_arff_path(arff_path, p_set_name)

    file_obj = open(arff_path, 'a+')
    file_obj.write('\n')
    file_obj.write('@data\n')
    file_obj.close()


def write_msg_arff_header(arff_path, p_set_name, relation):
    file_obj = open(arff_path, 'w')
    file_obj.write('@relation ' + relation + '\n\n')
    file_obj.close()

    message_feature.add_headers_to_message_arff_path(arff_path)
    file_obj = open(arff_path, 'a+')
    file_obj.write('\n')
    file_obj.write('@data\n')
    file_obj.close()

write_arff_header(file_name, p_set_name, relation)
#write_msg_arff_header(file_name, p_set_name, relation)
