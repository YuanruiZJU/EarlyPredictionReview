from features import feature_utils
p_set_name = 'openstack'
sorted_change_map = feature_utils.get_sorted_change_map(p_set_name)

abandoned = 0
merged = 0
i = 0
num = 0
len_sorted = len(sorted_change_map)
while num < len_sorted:
    try:
        ch = sorted_change_map[i]
    except:
        i += 1
        continue
    num += 1
    if ch.status == 'MERGED':
        merged += 1
    else:
        abandoned += 1
    i += 1

print "abandoned %s" % abandoned
print "merged %s" % merged