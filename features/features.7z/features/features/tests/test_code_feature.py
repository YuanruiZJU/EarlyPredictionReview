from features import feature_utils
from features import code_feature
from features import exceptions as feature_exception


def extract_features(p_set_name, sub_project_name):
    not_consistent_merged = 0
    not_consistent_abandoned = 0
    print 'reading sorted change map'
    sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
    len_sorted_map = len(sorted_change_map)
    i = 0
    num = 0
    number = 0
    print 'start extract features.'
    not_consistent_num = 0
    rename_file_changes = 0
    while num < len_sorted_map:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        try:
            num += 1

            code_features = code_feature.CodeFeatures(p_set_name, sub_project_name, ch)
            code_features.extract_features()
            code_features.print_features()
            if code_features['n_renamed_file'] > 0:
                rename_file_changes += 1

        except feature_exception.NotConsistentException:
            not_consistent_num += 1
            if ch.status == 'MERGED':
                not_consistent_merged += 1
            else:
                not_consistent_abandoned += 1
            print '%s not consistent.' % ch.change_number
            pass
        except IOError:
            pass
        i += 1
    print not_consistent_num
    print rename_file_changes
    print not_consistent_merged
    print not_consistent_abandoned


extract_features('eclipse', None)
