from features import social_networks

sn = social_networks.SocialNetwork('eclipse', 86096)
print sn.degree_centrality()
print sn.closeness_centrality()
print sn.betweenness_centrality()
print sn.clustering_coefficient()
print sn.eigenvector_centrality()
print sn.k_coreness()