from features import feature_utils
from features import message_feature


p_set_name = 'eclipse'
sub_project_name = None
sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
len_sorted = len(sorted_change_map)
arff_path = 'test.arff'

def test_message_feature():
    i = 0
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        msg_fs = message_feature.CommitMessageFeatures(p_set_name, sub_project_name, ch)
        msg_fs.extract_features()
        msg_fs.print_features()
        i += 1

def test_create_arff():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    i = 0
    num = 0
    while num < len_sorted:
        try:
            ch = sorted_change_map[i]
        except KeyError:
            i += 1
            continue
        num += 1
        msg_fs = message_feature.CommitMessageFeatures(p_set_name, ch)
        msg_fs.msg_to_arff(arff_path, 'message_train')
        i += 1

test_message_feature()
