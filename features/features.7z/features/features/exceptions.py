class NotConsistentException(Exception):
    def __init__(self):
        self.message = 'Git repo and code review is not consistent.'


class NoFileException(Exception):
    def __init__(self):
        self.message = 'There is no file written by required languages.'

