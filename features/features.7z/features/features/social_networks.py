import networkx as nx
from features import feature_utils


class SocialNetwork:
    def __init__(self, p_set_name, sub_project_name, change_number):
        self.graph = nx.Graph()
        sorted_change_map = feature_utils.get_sorted_change_map(p_set_name, sub_project_name)
        self.ch = sorted_change_map[change_number]
        self.owner = self.ch.owner
        self.construct_graph(change_number, sorted_change_map)
        self.lcc = self.largest_connected_component()

    def construct_graph(self, change_number, sorted_change_map):
        number = change_number - 1
        while number > 0:
            try:
                ch = sorted_change_map[number]
            except KeyError:
                number -= 1
                continue
            delta_day = feature_utils.delta_days(self.ch.created, ch.created)
            if delta_day > 30:
                break
            if delta_day >= 1 and self.ch.project == ch.project:
                owner = ch.owner
                reviewers = ch.reviewers
                for r in reviewers:
                    if r == owner:
                        continue
                    try:
                        self.graph[owner][r]['weight'] += 1
                    except (KeyError, IndexError):
                        self.graph.add_edge(owner, r, weight=1)
            number -= 1

    def show_graph(self):
        import matplotlib.pyplot as plt
        nx.draw(self.graph)
        plt.show()

    def largest_connected_component(self):
        try:
            return max(nx.connected_component_subgraphs(self.graph), key=len)
        except:
            return self.graph

    def degree_centrality(self):
        nodes_dict = nx.degree_centrality(self.lcc)
        try:
            return nodes_dict[self.owner]
        except KeyError:
            return 0

    def closeness_centrality(self):
        try:
            return nx.closeness_centrality(self.lcc, u=self.owner)
        except KeyError:
            return 0

    def betweenness_centrality(self):
        nodes_dict = nx.betweenness_centrality(self.lcc, weight='weight')
        try:
            return nodes_dict[self.owner]
        except KeyError:
            return 0

    def eigenvector_centrality(self):
        try:
            nodes_dict = nx.eigenvector_centrality_numpy(self.lcc)
        except:
            try:
                nodes_dict = nx.eigenvector_centrality(self.lcc)
            except:
                return 0
        try:
            return nodes_dict[self.owner]
        except KeyError:
            return 0

    def clustering_coefficient(self):
        try:
            return nx.clustering(self.lcc, nodes=self.owner, weight='weight')
        except nx.exception.NetworkXError:
            return 0

    def k_coreness(self):
        nodes_dict = nx.core_number(self.lcc)
        try:
            return nodes_dict[self.owner]
        except KeyError:
            return 0
