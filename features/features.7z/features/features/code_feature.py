from features import Features
from features import feature_utils
from baseline_features import baseline_utils
import code_review
import global_variable

import os


def add_headers_to_arff_path(arff_path, p_set_name):
    attributes = {}
    numeric_attr = 'numeric'
    fields = global_variable.feature_dict['code_features']
    for key in fields:
        attributes[key] = numeric_attr

    f_obj = open(arff_path, 'a+')
    for key in fields:
        f_obj.write('@attribute ')
        f_obj.write(key)
        f_obj.write(' ')
        f_obj.write(attributes[key])
        f_obj.write('\n')
    f_obj.close()


class CodeFeatures(Features):

    @staticmethod
    def get_feature_fields():
        return global_variable.feature_dict['code_features']

    def __init__(self, p_set_name, sub_project_name, simple_code_review):
        assert(isinstance(simple_code_review, code_review.SimpleCodeReview))
        change_number = simple_code_review.change_number
        super(CodeFeatures, self).__init__(change_number)
        self.status = simple_code_review.status
        self.feature_fields = self.get_feature_fields()
        self.files = simple_code_review.files
        self.git_show_path = global_variable.git_show_path + p_set_name + '/' + \
            simple_code_review.project + '/' + str(self.change_number) + '.txt'

    def extract_features(self):
        segs_added = 0
        segs_deleted = 0
        segs_updated = 0

        file_obj = open(self.git_show_path, 'r')
        git_show_file = file_obj.read()
        file_obj.close()
        lines = git_show_file.split('\n')

        file_diff_map = feature_utils.parse_git_show_file(lines, self.files)
        code_feature_fields = ['if_num', 'else_num', 'for_num', 'while_num', 'break_num',
                               'continue_num', 'return_num', 'try_num']
        for field in code_feature_fields:
            self[field] = 0
        for f in self.files:
            if f.insertions + f.deletions == 0:
                continue
            diff_map = file_diff_map[f.file_path]
            start_line = diff_map['start_line']
            end_line = diff_map['end_line']
            seg_maps = feature_utils.segments_maps(lines, start_line, end_line)
            for seg in seg_maps:
                seg_start_line = seg['start_line']
                seg_end_line = seg['end_line']
                has_plus, has_minus = feature_utils.check_update_type(lines, seg_start_line, seg_end_line)
                code_feature_map = baseline_utils.get_keywords_number(lines, seg_start_line, seg_end_line, code_feature_fields)
                if has_plus and has_minus:
                    segs_updated += 1
                elif has_plus:
                    segs_added += 1
                elif has_minus:
                    segs_deleted += 1
                for field in code_feature_fields:
                    self[field] += code_feature_map[field]
        self['segs_added_num'] = segs_added
        self['segs_deleted_num'] = segs_deleted
        self['segs_updated_num'] = segs_updated
